(() => {
  'use strict';

  const api = typeof browser !== 'undefined' ? browser : chrome;

  const STORAGE_KEY = 'rbuBlockedUsers';
  const SUB_STORAGE_KEY = 'rbuBlockedSubs';
  const SUB_WHITELIST_KEY = 'rbuWhitelistedSubs';
  const HIDE_KEYWORDS_KEY = 'rbuHideKeywords';
  const SAFE_KEYWORDS_KEY = 'rbuSafeKeywords';
  const AGGRESSIVE_KEYWORDS_KEY = 'rbuAggressiveKeywords';
  const LOG_KEY = 'rbuEventLog';
  const SWEEP_KEY = 'rbuAutoSweepEnabled';
  const SWEEP_DELAY_KEY = 'rbuAutoSweepDelayMs';
  const SUSPICIOUS_MODE_KEY = 'rbuSuspiciousModeEnabled';
  const SUSPICIOUS_THRESHOLD_KEY = 'rbuSuspiciousThreshold';
  const SUSPICIOUS_USERS_KEY = 'rbuSuspiciousUsers';
  const USER_META_KEY = 'rbuUserMeta';
  const HIDE_BLOCKED_POSTS_COMPLETELY_KEY = 'rbuHideBlockedPostsCompletely';
  const BLOCK_DECAY_ENABLED_KEY = 'rbuBlockDecayEnabled';
  const BLOCK_DECAY_DAYS_KEY = 'rbuBlockDecayDays';
  const SWEEP_SCORE_EXCEPTION_ENABLED_KEY = 'rbuSweepScoreExceptionEnabled';
  const SWEEP_SCORE_MIN_KEY = 'rbuSweepScoreMin';
  const SWEEP_SCORE_MAX_KEY = 'rbuSweepScoreMax';
  const SWEEP_MAX_POST_AGE_HOURS_KEY = 'rbuSweepMaxPostAgeHours';
  const SCAN_ENABLED_KEY = 'rbuAutoScanEnabled';
  const SCAN_POSTS_KEY = 'rbuScanPostsPerSub';
  const SCAN_THROTTLE_KEY = 'rbuScanThrottleMs';
  const SCAN_INTERVAL_KEY = 'rbuScanIntervalMinutes';
  const SCAN_LAST_KEY = 'rbuScanLastRun';
  const SCAN_STATUS_KEY = 'rbuScanLastStatus';
  const SCAN_ERROR_KEY = 'rbuScanLastError';
  const EXPORTABLE_KEYS = [
    STORAGE_KEY,
    SUB_STORAGE_KEY,
    SUB_WHITELIST_KEY,
    HIDE_KEYWORDS_KEY,
    SAFE_KEYWORDS_KEY,
    AGGRESSIVE_KEYWORDS_KEY,
    LOG_KEY,
    SWEEP_KEY,
    SWEEP_DELAY_KEY,
    SUSPICIOUS_MODE_KEY,
    SUSPICIOUS_THRESHOLD_KEY,
    SUSPICIOUS_USERS_KEY,
    USER_META_KEY,
    HIDE_BLOCKED_POSTS_COMPLETELY_KEY,
    BLOCK_DECAY_ENABLED_KEY,
    BLOCK_DECAY_DAYS_KEY,
    SWEEP_SCORE_EXCEPTION_ENABLED_KEY,
    SWEEP_SCORE_MIN_KEY,
    SWEEP_SCORE_MAX_KEY,
    SWEEP_MAX_POST_AGE_HOURS_KEY,
    SCAN_ENABLED_KEY,
    SCAN_POSTS_KEY,
    SCAN_THROTTLE_KEY,
    SCAN_INTERVAL_KEY
  ];
  const storage = api.storage.local;
  const DOUBLE_QUOTE_CHARS = /[\u0022\u201c\u201d\u201e\u201f\u00ab\u00bb\u301d\u301e\u301f\u2033\uff02]/g;

  const statusEl = document.getElementById('status');
  const logListEl = document.getElementById('log-list');
  const logEmptyEl = document.getElementById('log-empty');
  const exportLogBtn = document.getElementById('export-log');
  const importLogBtn = document.getElementById('import-log');
  const importLogFile = document.getElementById('import-log-file');
  const clearLogBtn = document.getElementById('clear-log');
  const exportAllBtn = document.getElementById('export-all');
  const importAllBtn = document.getElementById('import-all');
  const clearAllDataBtn = document.getElementById('clear-all-data');
  const importAllFile = document.getElementById('import-all-file');
  const form = document.getElementById('add-form');
  const input = document.getElementById('username');
  const listEl = document.getElementById('list');
  const emptyEl = document.getElementById('empty');
  const clearBtn = document.getElementById('clear');
  const exportBtn = document.getElementById('export-users');
  const importBtn = document.getElementById('import-users');
  const importFile = document.getElementById('import-file');
  const importStatus = document.getElementById('import-status');
  const hideKeywordForm = document.getElementById('add-hide-keyword-form');
  const hideKeywordInput = document.getElementById('hide-keyword');
  const hideKeywordRegexToggleBtn = document.getElementById('hide-keyword-regex-toggle');
  const hideKeywordListEl = document.getElementById('hide-keyword-list');
  const hideKeywordEmptyEl = document.getElementById('hide-keyword-empty');
  const hideKeywordClearBtn = document.getElementById('hide-keyword-clear');
  const safeKeywordForm = document.getElementById('add-safe-keyword-form');
  const safeKeywordInput = document.getElementById('safe-keyword');
  const safeKeywordRegexToggleBtn = document.getElementById('safe-keyword-regex-toggle');
  const safeKeywordListEl = document.getElementById('safe-keyword-list');
  const safeKeywordEmptyEl = document.getElementById('safe-keyword-empty');
  const safeKeywordClearBtn = document.getElementById('safe-keyword-clear');
  const exportSafeKeywordsBtn = document.getElementById('export-safe-keywords');
  const importSafeKeywordsBtn = document.getElementById('import-safe-keywords');
  const importSafeKeywordsFile = document.getElementById('import-safe-keywords-file');
  const aggressiveKeywordForm = document.getElementById('add-aggressive-keyword-form');
  const aggressiveKeywordInput = document.getElementById('aggressive-keyword');
  const aggressiveKeywordRegexToggleBtn = document.getElementById('aggressive-keyword-regex-toggle');
  const aggressiveKeywordListEl = document.getElementById('aggressive-keyword-list');
  const aggressiveKeywordEmptyEl = document.getElementById('aggressive-keyword-empty');
  const aggressiveKeywordClearBtn = document.getElementById('aggressive-keyword-clear');
  const exportHideKeywordsBtn = document.getElementById('export-hide-keywords');
  const importHideKeywordsBtn = document.getElementById('import-hide-keywords');
  const importHideKeywordsFile = document.getElementById('import-hide-keywords-file');
  const exportAggressiveKeywordsBtn = document.getElementById('export-aggressive-keywords');
  const importAggressiveKeywordsBtn = document.getElementById('import-aggressive-keywords');
  const importAggressiveKeywordsFile = document.getElementById('import-aggressive-keywords-file');
  const subForm = document.getElementById('add-sub-form');
  const subInput = document.getElementById('subreddit');
  const subListEl = document.getElementById('sub-list');
  const subEmptyEl = document.getElementById('sub-empty');
  const subClearBtn = document.getElementById('sub-clear');
  const exportBlockedSubsBtn = document.getElementById('export-blocked-subs');
  const importBlockedSubsBtn = document.getElementById('import-blocked-subs');
  const importBlockedSubsFile = document.getElementById('import-blocked-subs-file');
  const whitelistSubForm = document.getElementById('add-whitelist-sub-form');
  const whitelistSubInput = document.getElementById('whitelist-subreddit');
  const whitelistSubListEl = document.getElementById('whitelist-sub-list');
  const whitelistSubEmptyEl = document.getElementById('whitelist-sub-empty');
  const whitelistSubClearBtn = document.getElementById('whitelist-sub-clear');
  const exportWhitelistSubsBtn = document.getElementById('export-whitelist-subs');
  const importWhitelistSubsBtn = document.getElementById('import-whitelist-subs');
  const importWhitelistSubsFile = document.getElementById('import-whitelist-subs-file');
  const suspiciousModeInput = document.getElementById('suspicious-mode');
  const suspiciousThresholdInput = document.getElementById('suspicious-threshold');
  const suspiciousListEl = document.getElementById('suspicious-list');
  const suspiciousEmptyEl = document.getElementById('suspicious-empty');
  const suspiciousClearBtn = document.getElementById('suspicious-clear');
  const exportSuspiciousUsersBtn = document.getElementById('export-suspicious-users');
  const importSuspiciousUsersBtn = document.getElementById('import-suspicious-users');
  const importSuspiciousUsersFile = document.getElementById('import-suspicious-users-file');
  const hideBlockedPostsCompletelyInput = document.getElementById('hide-blocked-posts-completely');
  const blockDecayEnabledInput = document.getElementById('block-decay-enabled');
  const blockDecayDaysInput = document.getElementById('block-decay-days');
  const autoSweepInput = document.getElementById('auto-sweep');
  const sweepDelayInput = document.getElementById('sweep-delay');
  const sweepScoreExceptionEnabledInput = document.getElementById('sweep-score-exception-enabled');
  const sweepScoreMinInput = document.getElementById('sweep-score-min');
  const sweepScoreMaxInput = document.getElementById('sweep-score-max');
  const sweepMaxPostAgeHoursInput = document.getElementById('sweep-max-post-age-hours');
  const autoScanInput = document.getElementById('auto-scan');
  const scanPostsInput = document.getElementById('scan-posts');
  const scanThrottleInput = document.getElementById('scan-throttle');
  const scanIntervalInput = document.getElementById('scan-interval');
  const scanNowBtn = document.getElementById('scan-now');
  const scanStatusEl = document.getElementById('scan-status');
  const sweepUiAvailable = !!autoSweepInput && !!sweepDelayInput;
  const scanUiAvailable =
    !!autoScanInput && !!scanPostsInput && !!scanThrottleInput && !!scanIntervalInput && !!scanNowBtn && !!scanStatusEl;
  let hideKeywordRegexMode = false;
  let safeKeywordRegexMode = false;
  let aggressiveKeywordRegexMode = false;
  let blockedUsersCache = [];
  let blockedUserMetaCache = {};

  if (!api || !api.storage) {
    if (statusEl) {
      statusEl.textContent = 'Extension storage API unavailable. Reload the add-on or check about:debugging for errors.';
    }
    return;
  }

  function normalize(name) {
    if (!name) return '';
    let cleaned = name.trim();
    if (cleaned.startsWith('u/')) cleaned = cleaned.slice(2);
    if (cleaned.startsWith('/user/')) cleaned = cleaned.replace(/^\/user\//i, '');
    cleaned = cleaned.replace(/\/$/, '');
    return cleaned.toLowerCase();
  }

  function normalizeDoubleQuotes(text) {
    return (text || '').replace(DOUBLE_QUOTE_CHARS, '"');
  }

  function clampNumber(value, min, max, fallback) {
    const num = Number(value);
    if (!Number.isFinite(num)) return fallback;
    return Math.min(max, Math.max(min, num));
  }

  function normalizeSub(name) {
    if (!name) return '';
    let cleaned = name.trim();
    if (cleaned.startsWith('r/')) cleaned = cleaned.slice(2);
    if (cleaned.startsWith('/r/')) cleaned = cleaned.replace(/^\/r\//i, '');
    cleaned = cleaned.replace(/\/$/, '');
    return cleaned.toLowerCase();
  }

  function normalizeKeywordValue(value, useRegex) {
    const cleaned = normalizeDoubleQuotes((value || '').trim());
    return useRegex ? cleaned : cleaned.toLowerCase();
  }

  function normalizeKeywordEntry(entry) {
    if (typeof entry === 'string') {
      const value = normalizeKeywordValue(entry, false);
      return value ? { value, regex: false } : null;
    }
    if (!entry || typeof entry !== 'object') return null;
    const regex = Boolean(entry.regex);
    const value = normalizeKeywordValue(entry.value, regex);
    if (!value) return null;
    return { value, regex };
  }

  function normalizeKeywordEntries(list) {
    const normalized = (Array.isArray(list) ? list : []).map(normalizeKeywordEntry).filter(Boolean);
    const unique = new Map();
    for (const entry of normalized) {
      unique.set(`${entry.regex ? 'regex' : 'text'}:${entry.value}`, entry);
    }
    return Array.from(unique.values()).sort((a, b) => {
      const valueCompare = a.value.localeCompare(b.value);
      if (valueCompare !== 0) return valueCompare;
      return Number(a.regex) - Number(b.regex);
    });
  }

  function keywordEntryKey(entry) {
    return `${entry.regex ? 'regex' : 'text'}:${entry.value}`;
  }

  function isValidRegexPattern(value) {
    try {
      new RegExp(value, 'i');
      return true;
    } catch (err) {
      return false;
    }
  }

  function formatKeywordLabel(entry) {
    return entry.regex ? `/${entry.value}/` : entry.value;
  }

  function setRegexToggleButton(button, enabled) {
    if (!button) return;
    button.textContent = enabled ? 'Regex on' : 'Regex off';
    if (enabled) {
      button.classList.remove('ghost');
    } else {
      button.classList.add('ghost');
    }
  }

  async function getBlockedList() {
    const res = await storage.get(STORAGE_KEY);
    const arr = res && Array.isArray(res[STORAGE_KEY]) ? res[STORAGE_KEY] : [];
    return arr.map(normalize).filter(Boolean);
  }

  async function setBlockedList(list) {
    const unique = Array.from(new Set(list.map(normalize).filter(Boolean)));
    await storage.set({ [STORAGE_KEY]: unique });
    return unique;
  }

  function normalizeUserMetaMap(value) {
    const next = {};
    if (!value || typeof value !== 'object') return next;
    for (const [rawName, rawMeta] of Object.entries(value)) {
      const name = normalize(rawName);
      if (!name || !rawMeta || typeof rawMeta !== 'object') continue;
      next[name] = {
        reasonType: typeof rawMeta.reasonType === 'string' ? rawMeta.reasonType : '',
        reasonLabel: typeof rawMeta.reasonLabel === 'string' ? rawMeta.reasonLabel : '',
        keyword: typeof rawMeta.keyword === 'string' ? rawMeta.keyword : '',
        subreddit: typeof rawMeta.subreddit === 'string' ? normalizeSub(rawMeta.subreddit) : '',
        source: typeof rawMeta.source === 'string' ? rawMeta.source : '',
        blockedAt: rawMeta.blockedAt === undefined ? 0 : clampNumber(rawMeta.blockedAt, 0, Number.MAX_SAFE_INTEGER, 0)
      };
    }
    return next;
  }

  function normalizeSuspiciousEntries(value) {
    const next = {};
    if (!value || typeof value !== 'object') return next;
    for (const [rawName, rawEntry] of Object.entries(value)) {
      const name = normalize(rawName);
      if (!name || !rawEntry || typeof rawEntry !== 'object') continue;
      const rawSubs = rawEntry.subreddits && typeof rawEntry.subreddits === 'object' ? rawEntry.subreddits : {};
      const subreddits = {};
      for (const [rawSub, rawCount] of Object.entries(rawSubs)) {
        const sub = normalizeSub(rawSub);
        if (!sub) continue;
        subreddits[sub] = clampNumber(rawCount, 0, 1000000, 0);
      }
      next[name] = {
        count: clampNumber(rawEntry.count, 0, 1000000, 0),
        keywordHits: clampNumber(rawEntry.keywordHits, 0, 1000000, 0),
        subredditHits: clampNumber(rawEntry.subredditHits, 0, 1000000, 0),
        subreddits,
        lastReasonType: typeof rawEntry.lastReasonType === 'string' ? rawEntry.lastReasonType : '',
        lastKeyword: typeof rawEntry.lastKeyword === 'string' ? rawEntry.lastKeyword : '',
        lastSubreddit: typeof rawEntry.lastSubreddit === 'string' ? normalizeSub(rawEntry.lastSubreddit) : '',
        lastSeen: clampNumber(rawEntry.lastSeen, 0, Number.MAX_SAFE_INTEGER, Date.now()),
        lastContent: typeof rawEntry.lastContent === 'string' ? rawEntry.lastContent : '',
        lastHitKey: typeof rawEntry.lastHitKey === 'string' ? rawEntry.lastHitKey : ''
      };
    }
    return next;
  }

  function buildManualMeta(name) {
    const username = normalize(name);
    return {
      reasonType: 'manual',
      reasonLabel: 'Manual/unknown inclusion',
      keyword: '',
      subreddit: '',
      source: 'options',
      blockedAt: Date.now(),
      username
    };
  }

  function setImportStatus(message) {
    if (importStatus) importStatus.textContent = message || '';
  }

  function setStatus(message) {
    if (statusEl) statusEl.textContent = message || '';
  }

  function downloadJson(filename, payload) {
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  }

  function extractArrayPayload(parsed, keys = []) {
    if (Array.isArray(parsed)) return parsed;
    if (!parsed || typeof parsed !== 'object') return null;
    for (const key of keys) {
      if (Array.isArray(parsed[key])) return parsed[key];
    }
    if (parsed.data && Array.isArray(parsed.data)) return parsed.data;
    return null;
  }

  function extractObjectPayload(parsed, keys = []) {
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return null;
    for (const key of keys) {
      if (parsed[key] && typeof parsed[key] === 'object' && !Array.isArray(parsed[key])) return parsed[key];
    }
    if (parsed.data && typeof parsed.data === 'object' && !Array.isArray(parsed.data)) return parsed.data;
    return parsed;
  }

  async function readFileText(file) {
    if (!file) return '';
    return file.text();
  }

  function parseImportedStringList(text, normalizer) {
    if (!text) return [];
    const trimmed = text.trim();
    if (!trimmed) return [];
    try {
      const parsed = JSON.parse(trimmed);
      const arr = extractArrayPayload(parsed, ['users', 'subs', 'list', 'items']);
      if (arr) return arr.map((value) => normalizer(value)).filter(Boolean);
    } catch (err) {
      // fall back to newline parsing
    }
    return trimmed
      .split(/\r?\n/)
      .map((line) => normalizer(line))
      .filter(Boolean);
  }

  function parseImportedKeywordEntries(text) {
    if (!text) return [];
    const trimmed = text.trim();
    if (!trimmed) return [];
    try {
      const parsed = JSON.parse(trimmed);
      const arr = extractArrayPayload(parsed, ['keywords', 'list', 'items']);
      if (arr) return normalizeKeywordEntries(arr);
    } catch (err) {
      // fall through to line parsing
    }
    return normalizeKeywordEntries(
      trimmed
        .split(/\r?\n/)
        .map((line) => line.trim())
        .filter(Boolean)
    );
  }

  function normalizeLogEntries(list) {
    return (Array.isArray(list) ? list : [])
      .filter((entry) => entry && typeof entry === 'object')
      .map((entry) => ({
        timestamp: typeof entry.timestamp === 'string' ? entry.timestamp : new Date().toISOString(),
        type: typeof entry.type === 'string' ? entry.type : 'info',
        user: typeof entry.user === 'string' ? entry.user : '',
        keyword: typeof entry.keyword === 'string' ? entry.keyword : '',
        regex: Boolean(entry.regex),
        source: typeof entry.source === 'string' ? entry.source : '',
        subreddit: typeof entry.subreddit === 'string' ? entry.subreddit : '',
        url: typeof entry.url === 'string' ? entry.url : '',
        content: typeof entry.content === 'string' ? entry.content : ''
      }))
      .slice(0, 200);
  }

  function parseImportedUsers(text) {
    if (!text) return [];
    const trimmed = text.trim();
    if (!trimmed) return [];
    try {
      const parsed = JSON.parse(trimmed);
      if (Array.isArray(parsed)) return parsed.map(normalize).filter(Boolean);
    } catch (err) {
      // fall through to line parsing
    }
    return trimmed
      .split(/\r?\n/)
      .map((line) => normalize(line))
      .filter(Boolean);
  }

  function sanitizeImportedData(data) {
    const payload = {};
    if (!data || typeof data !== 'object') return payload;

    if (Array.isArray(data[STORAGE_KEY])) {
      payload[STORAGE_KEY] = Array.from(new Set(data[STORAGE_KEY].map(normalize).filter(Boolean))).sort();
    }
    if (Array.isArray(data[SUB_STORAGE_KEY])) {
      payload[SUB_STORAGE_KEY] = Array.from(new Set(data[SUB_STORAGE_KEY].map(normalizeSub).filter(Boolean))).sort();
    }
    if (Array.isArray(data[SUB_WHITELIST_KEY])) {
      payload[SUB_WHITELIST_KEY] = Array.from(new Set(data[SUB_WHITELIST_KEY].map(normalizeSub).filter(Boolean))).sort();
    }
    if (Array.isArray(data[HIDE_KEYWORDS_KEY])) {
      payload[HIDE_KEYWORDS_KEY] = normalizeKeywordEntries(data[HIDE_KEYWORDS_KEY]);
    }
    if (Array.isArray(data[SAFE_KEYWORDS_KEY])) {
      payload[SAFE_KEYWORDS_KEY] = normalizeKeywordEntries(data[SAFE_KEYWORDS_KEY]);
    }
    if (Array.isArray(data[AGGRESSIVE_KEYWORDS_KEY])) {
      payload[AGGRESSIVE_KEYWORDS_KEY] = normalizeKeywordEntries(data[AGGRESSIVE_KEYWORDS_KEY]);
    }
    if (Array.isArray(data[LOG_KEY])) {
      payload[LOG_KEY] = normalizeLogEntries(data[LOG_KEY]);
    }
    if (typeof data[SUSPICIOUS_MODE_KEY] === 'boolean') {
      payload[SUSPICIOUS_MODE_KEY] = data[SUSPICIOUS_MODE_KEY];
    }
    if (data[SUSPICIOUS_THRESHOLD_KEY] !== undefined) {
      payload[SUSPICIOUS_THRESHOLD_KEY] = clampNumber(data[SUSPICIOUS_THRESHOLD_KEY], 1, 100, 2);
    }
    if (data[SUSPICIOUS_USERS_KEY] && typeof data[SUSPICIOUS_USERS_KEY] === 'object') {
      payload[SUSPICIOUS_USERS_KEY] = normalizeSuspiciousEntries(data[SUSPICIOUS_USERS_KEY]);
    }
    if (data[USER_META_KEY] && typeof data[USER_META_KEY] === 'object') {
      payload[USER_META_KEY] = normalizeUserMetaMap(data[USER_META_KEY]);
    }
    if (typeof data[HIDE_BLOCKED_POSTS_COMPLETELY_KEY] === 'boolean') {
      payload[HIDE_BLOCKED_POSTS_COMPLETELY_KEY] = data[HIDE_BLOCKED_POSTS_COMPLETELY_KEY];
    }
    if (typeof data[BLOCK_DECAY_ENABLED_KEY] === 'boolean') {
      payload[BLOCK_DECAY_ENABLED_KEY] = data[BLOCK_DECAY_ENABLED_KEY];
    }
    if (data[BLOCK_DECAY_DAYS_KEY] !== undefined) {
      payload[BLOCK_DECAY_DAYS_KEY] = clampNumber(data[BLOCK_DECAY_DAYS_KEY], 1, 3650, 30);
    }
    if (typeof data[SWEEP_KEY] === 'boolean') {
      payload[SWEEP_KEY] = data[SWEEP_KEY];
    }
    if (data[SWEEP_DELAY_KEY] !== undefined) {
      payload[SWEEP_DELAY_KEY] = Math.max(500, Math.min(30000, Number(data[SWEEP_DELAY_KEY]) || 3000));
    }
    if (typeof data[SWEEP_SCORE_EXCEPTION_ENABLED_KEY] === 'boolean') {
      payload[SWEEP_SCORE_EXCEPTION_ENABLED_KEY] = data[SWEEP_SCORE_EXCEPTION_ENABLED_KEY];
    }
    if (data[SWEEP_SCORE_MIN_KEY] !== undefined) {
      payload[SWEEP_SCORE_MIN_KEY] = clampNumber(data[SWEEP_SCORE_MIN_KEY], -1000000, 1000000, -1);
    }
    if (data[SWEEP_SCORE_MAX_KEY] !== undefined) {
      payload[SWEEP_SCORE_MAX_KEY] = clampNumber(data[SWEEP_SCORE_MAX_KEY], -1000000, 1000000, 1);
    }
    if (data[SWEEP_MAX_POST_AGE_HOURS_KEY] !== undefined) {
      payload[SWEEP_MAX_POST_AGE_HOURS_KEY] = clampNumber(data[SWEEP_MAX_POST_AGE_HOURS_KEY], 0, 87600, 0);
    }
    if (typeof data[SCAN_ENABLED_KEY] === 'boolean') {
      payload[SCAN_ENABLED_KEY] = data[SCAN_ENABLED_KEY];
    }
    if (data[SCAN_POSTS_KEY] !== undefined) {
      payload[SCAN_POSTS_KEY] = Math.max(1, Math.min(100, Number(data[SCAN_POSTS_KEY]) || 10));
    }
    if (data[SCAN_THROTTLE_KEY] !== undefined) {
      payload[SCAN_THROTTLE_KEY] = Math.max(0, Math.min(10000, Number(data[SCAN_THROTTLE_KEY]) || 2000));
    }
    if (data[SCAN_INTERVAL_KEY] !== undefined) {
      payload[SCAN_INTERVAL_KEY] = Math.max(1, Math.min(525600, Number(data[SCAN_INTERVAL_KEY]) || 10080));
    }

    return payload;
  }

  function getAllExportData() {
    return storage.get(EXPORTABLE_KEYS).then((data) => ({
      version: 1,
      exportedAt: new Date().toISOString(),
      data: sanitizeImportedData(data)
    }));
  }

  async function getBlockedSubs() {
    const res = await storage.get(SUB_STORAGE_KEY);
    const arr = res && Array.isArray(res[SUB_STORAGE_KEY]) ? res[SUB_STORAGE_KEY] : [];
    return arr.map(normalizeSub).filter(Boolean);
  }

  async function getWhitelistedSubs() {
    const res = await storage.get(SUB_WHITELIST_KEY);
    const arr = res && Array.isArray(res[SUB_WHITELIST_KEY]) ? res[SUB_WHITELIST_KEY] : [];
    return arr.map(normalizeSub).filter(Boolean);
  }

  async function getKeywordList(key) {
    const res = await storage.get(key);
    const arr = res && Array.isArray(res[key]) ? res[key] : [];
    return normalizeKeywordEntries(arr);
  }

  async function setBlockedSubs(list) {
    const unique = Array.from(new Set(list.map(normalizeSub).filter(Boolean))).sort();
    await storage.set({ [SUB_STORAGE_KEY]: unique });
    return unique;
  }

  async function setWhitelistedSubs(list) {
    const unique = Array.from(new Set(list.map(normalizeSub).filter(Boolean))).sort();
    await storage.set({ [SUB_WHITELIST_KEY]: unique });
    return unique;
  }

  async function setKeywordList(key, list) {
    const unique = normalizeKeywordEntries(list);
    await storage.set({ [key]: unique });
    return unique;
  }

  async function getSuspiciousSettings() {
    const res = await storage.get([SUSPICIOUS_MODE_KEY, SUSPICIOUS_THRESHOLD_KEY]);
    return {
      enabled: Boolean(res[SUSPICIOUS_MODE_KEY]),
      threshold: clampNumber(res[SUSPICIOUS_THRESHOLD_KEY], 1, 100, 2)
    };
  }

  async function setSuspiciousSettings(enabled, threshold) {
    const safeThreshold = clampNumber(threshold, 1, 100, 2);
    await storage.set({
      [SUSPICIOUS_MODE_KEY]: Boolean(enabled),
      [SUSPICIOUS_THRESHOLD_KEY]: safeThreshold
    });
    return { enabled: Boolean(enabled), threshold: safeThreshold };
  }

  async function getSuspiciousList() {
    const res = await storage.get(SUSPICIOUS_USERS_KEY);
    return normalizeSuspiciousEntries(res[SUSPICIOUS_USERS_KEY]);
  }

  async function setSuspiciousList(value) {
    const normalized = normalizeSuspiciousEntries(value);
    await storage.set({ [SUSPICIOUS_USERS_KEY]: normalized });
    return normalized;
  }

  async function getPostDisplaySettings() {
    const res = await storage.get([
      HIDE_BLOCKED_POSTS_COMPLETELY_KEY,
      BLOCK_DECAY_ENABLED_KEY,
      BLOCK_DECAY_DAYS_KEY
    ]);
    return {
      hideBlockedPostsCompletely: Boolean(res[HIDE_BLOCKED_POSTS_COMPLETELY_KEY]),
      decayEnabled: Boolean(res[BLOCK_DECAY_ENABLED_KEY]),
      decayDays: clampNumber(res[BLOCK_DECAY_DAYS_KEY], 1, 3650, 30)
    };
  }

  async function setPostDisplaySettings(hideCompletely, decayEnabled, decayDays) {
    const safeDecayDays = clampNumber(decayDays, 1, 3650, 30);
    await storage.set({
      [HIDE_BLOCKED_POSTS_COMPLETELY_KEY]: Boolean(hideCompletely),
      [BLOCK_DECAY_ENABLED_KEY]: Boolean(decayEnabled),
      [BLOCK_DECAY_DAYS_KEY]: safeDecayDays
    });
    return {
      hideBlockedPostsCompletely: Boolean(hideCompletely),
      decayEnabled: Boolean(decayEnabled),
      decayDays: safeDecayDays
    };
  }

  async function getSweepSettings() {
    const res = await storage.get([
      SWEEP_KEY,
      SWEEP_DELAY_KEY,
      SWEEP_SCORE_EXCEPTION_ENABLED_KEY,
      SWEEP_SCORE_MIN_KEY,
      SWEEP_SCORE_MAX_KEY,
      SWEEP_MAX_POST_AGE_HOURS_KEY
    ]);
    return {
      enabled: Boolean(res[SWEEP_KEY]),
      delayMs: Number(res[SWEEP_DELAY_KEY]) || 3000,
      scoreExceptionEnabled: Boolean(res[SWEEP_SCORE_EXCEPTION_ENABLED_KEY]),
      scoreMin: clampNumber(res[SWEEP_SCORE_MIN_KEY], -1000000, 1000000, -1),
      scoreMax: clampNumber(res[SWEEP_SCORE_MAX_KEY], -1000000, 1000000, 1),
      maxPostAgeHours: clampNumber(res[SWEEP_MAX_POST_AGE_HOURS_KEY], 0, 87600, 0)
    };
  }

  async function setSweepSettings(enabled, delayMs, scoreExceptionEnabled, scoreMin, scoreMax, maxPostAgeHours) {
    const safeDelay = Math.max(500, Math.min(30000, delayMs));
    const safeScoreMin = clampNumber(scoreMin, -1000000, 1000000, -1);
    const safeScoreMax = clampNumber(scoreMax, -1000000, 1000000, 1);
    const safeMaxPostAgeHours = clampNumber(maxPostAgeHours, 0, 87600, 0);
    await storage.set({
      [SWEEP_KEY]: Boolean(enabled),
      [SWEEP_DELAY_KEY]: safeDelay,
      [SWEEP_SCORE_EXCEPTION_ENABLED_KEY]: Boolean(scoreExceptionEnabled),
      [SWEEP_SCORE_MIN_KEY]: safeScoreMin,
      [SWEEP_SCORE_MAX_KEY]: safeScoreMax,
      [SWEEP_MAX_POST_AGE_HOURS_KEY]: safeMaxPostAgeHours
    });
    return {
      enabled: Boolean(enabled),
      delayMs: safeDelay,
      scoreExceptionEnabled: Boolean(scoreExceptionEnabled),
      scoreMin: safeScoreMin,
      scoreMax: safeScoreMax,
      maxPostAgeHours: safeMaxPostAgeHours
    };
  }

  async function getScanSettings() {
    const res = await storage.get([SCAN_ENABLED_KEY, SCAN_POSTS_KEY, SCAN_THROTTLE_KEY, SCAN_INTERVAL_KEY]);
    return {
      enabled: Boolean(res[SCAN_ENABLED_KEY]),
      postsPerSub: Number(res[SCAN_POSTS_KEY]) || 10,
      throttleMs: Number(res[SCAN_THROTTLE_KEY]) || 2000,
      intervalMinutes: Number(res[SCAN_INTERVAL_KEY]) || 10080
    };
  }

  async function setScanSettings(enabled, postsPerSub, throttleMs, intervalMinutes) {
    const safePosts = Math.max(1, Math.min(100, postsPerSub));
    const safeThrottle = Math.max(0, Math.min(10000, throttleMs));
    const safeInterval = Math.max(1, Math.min(525600, intervalMinutes));
    await storage.set({
      [SCAN_ENABLED_KEY]: Boolean(enabled),
      [SCAN_POSTS_KEY]: safePosts,
      [SCAN_THROTTLE_KEY]: safeThrottle,
      [SCAN_INTERVAL_KEY]: safeInterval
    });
    return {
      enabled: Boolean(enabled),
      postsPerSub: safePosts,
      throttleMs: safeThrottle,
      intervalMinutes: safeInterval
    };
  }

  async function addBlockedUsersWithManualMeta(names) {
    const normalized = Array.from(new Set((Array.isArray(names) ? names : []).map(normalize).filter(Boolean)));
    if (!normalized.length) return getBlockedList();
    const res = await storage.get([STORAGE_KEY, USER_META_KEY, SUSPICIOUS_USERS_KEY]);
    const currentBlocked = Array.isArray(res[STORAGE_KEY]) ? res[STORAGE_KEY].map(normalize).filter(Boolean) : [];
    const currentMeta = normalizeUserMetaMap(res[USER_META_KEY]);
    const suspicious = normalizeSuspiciousEntries(res[SUSPICIOUS_USERS_KEY]);
    const merged = new Set(currentBlocked);
    for (const name of normalized) {
      merged.add(name);
      if (!currentMeta[name]) {
        currentMeta[name] = buildManualMeta(name);
      }
      delete suspicious[name];
    }
    const updated = Array.from(merged);
    await storage.set({
      [STORAGE_KEY]: updated,
      [USER_META_KEY]: currentMeta,
      [SUSPICIOUS_USERS_KEY]: suspicious
    });
    return updated;
  }

  async function pruneExpiredBlockedUsers() {
    const settings = await getPostDisplaySettings();
    if (!settings.decayEnabled) return;
    const ttlMs = settings.decayDays * 24 * 60 * 60 * 1000;
    const res = await storage.get([STORAGE_KEY, USER_META_KEY, SUSPICIOUS_USERS_KEY]);
    const currentBlocked = Array.isArray(res[STORAGE_KEY]) ? res[STORAGE_KEY].map(normalize).filter(Boolean) : [];
    const currentMeta = normalizeUserMetaMap(res[USER_META_KEY]);
    const suspicious = normalizeSuspiciousEntries(res[SUSPICIOUS_USERS_KEY]);
    const now = Date.now();
    const nextBlocked = [];
    let changed = false;
    for (const name of currentBlocked) {
      const meta = currentMeta[name];
      if (meta && meta.blockedAt && now - meta.blockedAt >= ttlMs) {
        delete currentMeta[name];
        delete suspicious[name];
        changed = true;
        continue;
      }
      nextBlocked.push(name);
    }
    if (changed) {
      await storage.set({
        [STORAGE_KEY]: nextBlocked,
        [USER_META_KEY]: currentMeta,
        [SUSPICIOUS_USERS_KEY]: suspicious
      });
    }
  }

  async function removeBlockedUserWithMeta(name) {
    const username = normalize(name);
    if (!username) return getBlockedList();
    const res = await storage.get([STORAGE_KEY, USER_META_KEY, SUSPICIOUS_USERS_KEY]);
    const currentBlocked = Array.isArray(res[STORAGE_KEY]) ? res[STORAGE_KEY].map(normalize).filter(Boolean) : [];
    const currentMeta = normalizeUserMetaMap(res[USER_META_KEY]);
    const suspicious = normalizeSuspiciousEntries(res[SUSPICIOUS_USERS_KEY]);
    const next = currentBlocked.filter((entry) => entry !== username);
    delete currentMeta[username];
    delete suspicious[username];
    await storage.set({
      [STORAGE_KEY]: next,
      [USER_META_KEY]: currentMeta,
      [SUSPICIOUS_USERS_KEY]: suspicious
    });
    return next;
  }

  function formatTimestamp(ts) {
    if (!ts) return '';
    const date = new Date(ts);
    if (Number.isNaN(date.getTime())) return '';
    return date.toLocaleString();
  }

  function renderScanStatus(status, lastRun, error) {
    if (!scanStatusEl) return;
    if (!status) {
      scanStatusEl.textContent = '';
      return;
    }
    if (status === 'running') {
      scanStatusEl.textContent = 'Scan running...';
      return;
    }
    if (status === 'error') {
      scanStatusEl.textContent = `Last scan failed: ${error || 'Unknown error'}`;
      return;
    }
    if (status === 'success') {
      const when = formatTimestamp(lastRun);
      scanStatusEl.textContent = when ? `Last scan: ${when}` : 'Last scan completed.';
      return;
    }
    if (status === 'canceled') {
      scanStatusEl.textContent = 'Scan canceled.';
      return;
    }
    scanStatusEl.textContent = '';
  }

  function requestStopScan() {
    if (!scanStatusEl) return;
    scanStatusEl.textContent = 'Stopping scan...';
    api.runtime.sendMessage({ type: 'rbu-scan-stop' }, () => {
      if (api.runtime.lastError) {
        scanStatusEl.textContent = 'Failed to stop scan.';
        return;
      }
      scanStatusEl.textContent = 'Stop requested...';
    });
  }

  function getBlockedUserReason(meta) {
    if (!meta) return 'Unknown reason/manual inclusion';
    if (meta.reasonLabel) return meta.reasonLabel;
    if (meta.keyword) return `Triggered keyword blocker (${meta.keyword})`;
    if (meta.subreddit) return `Participated in blocked subreddit r/${meta.subreddit}`;
    return 'Unknown reason/manual inclusion';
  }

  function formatBlockedDate(value) {
    if (!value) return 'Unknown date';
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return 'Unknown date';
    return date.toLocaleString();
  }

  function render(list, metaMap = blockedUserMetaCache) {
    blockedUsersCache = Array.isArray(list) ? list.slice() : [];
    blockedUserMetaCache = normalizeUserMetaMap(metaMap);
    listEl.innerHTML = '';

    if (!list.length) {
      emptyEl.style.display = 'block';
      return;
    }

    emptyEl.style.display = 'none';

    for (const user of list) {
      const li = document.createElement('li');
      li.className = 'item';

      const meta = blockedUserMetaCache[user];
      const details = document.createElement('div');
      details.className = 'stack';

      const title = document.createElement('strong');
      title.textContent = `u/${user}`;

      const reason = document.createElement('span');
      reason.className = 'note';
      reason.textContent = `Reason: ${getBlockedUserReason(meta)}`;

      const date = document.createElement('span');
      date.className = 'note';
      date.textContent = `Blocked: ${formatBlockedDate(meta && meta.blockedAt)}`;

      details.appendChild(title);
      details.appendChild(reason);
      details.appendChild(date);

      const btn = document.createElement('button');
      btn.type = 'button';
      btn.textContent = 'Remove';
      btn.addEventListener('click', async () => {
        const updated = await removeBlockedUserWithMeta(user);
        const data = await storage.get(USER_META_KEY);
        render(updated, normalizeUserMetaMap(data[USER_META_KEY]));
      });

      li.appendChild(details);
      li.appendChild(btn);
      listEl.appendChild(li);
    }
  }

  function renderSubs(list) {
    subListEl.innerHTML = '';

    if (!list.length) {
      subEmptyEl.style.display = 'block';
      return;
    }

    subEmptyEl.style.display = 'none';

    for (const sub of list) {
      const li = document.createElement('li');
      li.className = 'item';

      const span = document.createElement('span');
      span.textContent = `r/${sub}`;

      const btn = document.createElement('button');
      btn.type = 'button';
      btn.textContent = 'Remove';
      btn.addEventListener('click', async () => {
        const next = list.filter((name) => name !== sub);
        const updated = await setBlockedSubs(next);
        renderSubs(updated);
      });

      li.appendChild(span);
      li.appendChild(btn);
      subListEl.appendChild(li);
    }
  }

  function renderWhitelistSubs(list) {
    if (!whitelistSubListEl || !whitelistSubEmptyEl) return;
    whitelistSubListEl.innerHTML = '';

    if (!list.length) {
      whitelistSubEmptyEl.style.display = 'block';
      return;
    }

    whitelistSubEmptyEl.style.display = 'none';

    for (const sub of list) {
      const li = document.createElement('li');
      li.className = 'item';

      const span = document.createElement('span');
      span.textContent = `r/${sub}`;

      const btn = document.createElement('button');
      btn.type = 'button';
      btn.textContent = 'Remove';
      btn.addEventListener('click', async () => {
        const next = list.filter((name) => name !== sub);
        const updated = await setWhitelistedSubs(next);
        renderWhitelistSubs(updated);
      });

      li.appendChild(span);
      li.appendChild(btn);
      whitelistSubListEl.appendChild(li);
    }
  }

  function renderKeywords(listElRef, emptyElRef, list, storageKey) {
    if (!listElRef || !emptyElRef) return;
    listElRef.innerHTML = '';

    if (!list.length) {
      emptyElRef.style.display = 'block';
      return;
    }

    emptyElRef.style.display = 'none';

    for (const keyword of list) {
      const li = document.createElement('li');
      li.className = 'item';

      const span = document.createElement('span');
      span.textContent = formatKeywordLabel(keyword);

      const actions = document.createElement('div');
      actions.className = 'item-actions';

      const regexBtn = document.createElement('button');
      regexBtn.type = 'button';
      setRegexToggleButton(regexBtn, keyword.regex);
      regexBtn.addEventListener('click', async (event) => {
        event.preventDefault();
        event.stopPropagation();
        const toggled = {
          value: normalizeKeywordValue(keyword.value, !keyword.regex),
          regex: !keyword.regex
        };
        if (toggled.regex && !isValidRegexPattern(toggled.value)) {
          setStatus('Invalid regular expression.');
          return;
        }
        const next = list.map((entry) => (keywordEntryKey(entry) === keywordEntryKey(keyword) ? toggled : entry));
        const updated = await setKeywordList(storageKey, next);
        renderKeywords(listElRef, emptyElRef, updated, storageKey);
        setStatus('');
      });

      const btn = document.createElement('button');
      btn.type = 'button';
      btn.textContent = 'Remove';
      btn.addEventListener('click', async () => {
        const next = list.filter((entry) => keywordEntryKey(entry) !== keywordEntryKey(keyword));
        const updated = await setKeywordList(storageKey, next);
        renderKeywords(listElRef, emptyElRef, updated, storageKey);
      });

      actions.appendChild(regexBtn);
      actions.appendChild(btn);
      li.appendChild(span);
      li.appendChild(actions);
      listElRef.appendChild(li);
    }
  }

  function renderLog(entries) {
    if (!logListEl || !logEmptyEl) return;
    logListEl.innerHTML = '';

    if (!entries.length) {
      logEmptyEl.style.display = 'block';
      return;
    }

    logEmptyEl.style.display = 'none';

    for (const entry of entries) {
      const li = document.createElement('li');
      li.className = 'item log-item';

      const timestamp = new Date(entry.timestamp);
      const when = Number.isNaN(timestamp.getTime()) ? entry.timestamp : timestamp.toLocaleString();
      const details = document.createElement('details');
      details.className = 'log-entry';
      const summary = document.createElement('summary');
      if (entry.type === 'auto_block_keyword') {
        summary.textContent = `${when} - blocked u/${entry.user} from ${entry.source || 'keyword'} via ${
          entry.keyword || 'keyword'
        }`;
      } else if (entry.type === 'added_to_suspicious_list') {
        summary.textContent = `${when} - added u/${entry.user} to suspicious list${
          entry.keyword ? ` via ${entry.keyword}` : entry.subreddit ? ` via r/${entry.subreddit}` : ''
        }`;
      } else {
        summary.textContent = `${when} - ${entry.type}`;
      }

      const meta = document.createElement('div');
      meta.className = 'note';
      meta.textContent = `Source: ${entry.source || 'unknown'} | Keyword: ${entry.keyword || 'n/a'}${
        entry.subreddit ? ` | Subreddit: r/${entry.subreddit}` : ''
      }`;

      const contentLabel = document.createElement('div');
      contentLabel.className = 'note';
      contentLabel.textContent = entry.content ? 'Matched content:' : 'Matched content not captured for this entry.';

      details.appendChild(summary);
      details.appendChild(meta);
      details.appendChild(contentLabel);

      if (entry.content) {
        const content = document.createElement('div');
        content.className = 'log-content';
        content.textContent = entry.content;
        details.appendChild(content);
      }

      if (entry.url) {
        const link = document.createElement('a');
        link.href = entry.url;
        link.target = '_blank';
        link.rel = 'noopener noreferrer';
        link.textContent = 'Open source page';
        details.appendChild(link);
      }

      li.appendChild(details);
      logListEl.appendChild(li);
    }
  }

  function renderSuspiciousList(entries) {
    if (!suspiciousListEl || !suspiciousEmptyEl) return;
    suspiciousListEl.innerHTML = '';
    const rows = Object.entries(entries || {}).sort((a, b) => {
      const left = (b[1] && b[1].lastSeen) || 0;
      const right = (a[1] && a[1].lastSeen) || 0;
      return left - right;
    });

    if (!rows.length) {
      suspiciousEmptyEl.style.display = 'block';
      return;
    }

    suspiciousEmptyEl.style.display = 'none';

    for (const [user, entry] of rows) {
      const li = document.createElement('li');
      li.className = 'item';

      const details = document.createElement('div');
      details.className = 'stack';
      const title = document.createElement('strong');
      title.textContent = `u/${user}`;
      const meta = document.createElement('span');
      meta.className = 'note';
      meta.textContent = `Hits: ${entry.count || 0} | Keywords: ${entry.keywordHits || 0} | Subreddit hits: ${
        entry.subredditHits || 0
      }${entry.lastKeyword ? ` | Last keyword: ${entry.lastKeyword}` : ''}${
        entry.lastSubreddit ? ` | Last subreddit: r/${entry.lastSubreddit}` : ''
      }`;
      details.appendChild(title);
      details.appendChild(meta);

      const btn = document.createElement('button');
      btn.type = 'button';
      btn.textContent = 'Remove';
      btn.addEventListener('click', async () => {
        const next = normalizeSuspiciousEntries(entries);
        delete next[user];
        const updated = await setSuspiciousList(next);
        renderSuspiciousList(updated);
      });

      li.appendChild(details);
      li.appendChild(btn);
      suspiciousListEl.appendChild(li);
    }
  }

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    const raw = input.value;
    const user = normalize(raw);
    if (!user) return;
    const updated = await addBlockedUsersWithManualMeta([user]);
    const data = await storage.get(USER_META_KEY);
    render(updated, normalizeUserMetaMap(data[USER_META_KEY]));
    input.value = '';
  });

  clearBtn.addEventListener('click', async () => {
    await storage.set({ [STORAGE_KEY]: [], [USER_META_KEY]: {}, [SUSPICIOUS_USERS_KEY]: {} });
    const updated = [];
    render(updated, {});
  });

  if (exportAllBtn) {
    exportAllBtn.addEventListener('click', async () => {
      const payload = await getAllExportData();
      downloadJson('reddit-block-all-data.json', payload);
      setStatus('Exported full extension data.');
    });
  }

  if (exportLogBtn) {
    exportLogBtn.addEventListener('click', async () => {
      const data = await storage.get(LOG_KEY);
      downloadJson('reddit-block-log.json', {
        version: 1,
        exportedAt: new Date().toISOString(),
        logs: normalizeLogEntries(data[LOG_KEY])
      });
      setStatus('Exported activity log.');
    });
  }

  if (importLogBtn && importLogFile) {
    importLogBtn.addEventListener('click', () => {
      importLogFile.click();
    });

    importLogFile.addEventListener('change', async () => {
      const file = importLogFile.files && importLogFile.files[0];
      if (!file) return;
      try {
        const text = await readFileText(file);
        const parsed = JSON.parse(text);
        const imported = normalizeLogEntries(extractArrayPayload(parsed, ['logs', 'entries', 'list']) || []);
        const existingRes = await storage.get(LOG_KEY);
        const existing = normalizeLogEntries(existingRes[LOG_KEY]);
        const merged = normalizeLogEntries(imported.concat(existing));
        await storage.set({ [LOG_KEY]: merged });
        setStatus(`Imported ${imported.length} log entries.`);
      } catch (err) {
        setStatus('Log import failed. Use a valid JSON log export file.');
      } finally {
        importLogFile.value = '';
      }
    });
  }

  if (importAllBtn && importAllFile) {
    importAllBtn.addEventListener('click', () => {
      importAllFile.click();
    });

    importAllFile.addEventListener('change', async () => {
      const file = importAllFile.files && importAllFile.files[0];
      if (!file) return;
      try {
        const text = await file.text();
        const parsed = JSON.parse(text);
        const rawData = parsed && typeof parsed === 'object' && parsed.data && typeof parsed.data === 'object' ? parsed.data : parsed;
        const sanitized = sanitizeImportedData(rawData);
        await storage.remove(EXPORTABLE_KEYS);
        await storage.set(sanitized);
        setStatus('Imported full extension data.');
      } catch (err) {
        setStatus('Full import failed. Use a valid JSON export file.');
      } finally {
        importAllFile.value = '';
      }
    });
  }

  if (clearAllDataBtn) {
    clearAllDataBtn.addEventListener('click', async () => {
      await storage.remove(EXPORTABLE_KEYS);
      setStatus('Cleared all extension data.');
    });
  }

  if (clearLogBtn) {
    clearLogBtn.addEventListener('click', async () => {
      await storage.remove(LOG_KEY);
      setStatus('Cleared activity log.');
    });
  }

  exportBtn.addEventListener('click', async () => {
    const list = await getBlockedList();
    const metaRes = await storage.get(USER_META_KEY);
    downloadJson('reddit-block-users.json', {
      version: 1,
      type: 'blocked_users',
      users: list,
      meta: normalizeUserMetaMap(metaRes[USER_META_KEY])
    });
  });

  importBtn.addEventListener('click', () => {
    if (importFile) importFile.click();
  });

  importFile.addEventListener('change', async () => {
    const file = importFile.files && importFile.files[0];
    if (!file) return;
    try {
      const text = await file.text();
      let incoming = [];
      let importedMeta = {};
      try {
        const parsed = JSON.parse(text);
        const arr = extractArrayPayload(parsed, ['users', 'list', 'items']);
        if (arr) {
          incoming = arr.map((value) => normalize(value)).filter(Boolean);
          importedMeta = normalizeUserMetaMap((parsed && parsed.meta) || {});
        } else {
          incoming = parseImportedUsers(text);
        }
      } catch (err) {
        incoming = parseImportedUsers(text);
      }
      const updated = await addBlockedUsersWithManualMeta(incoming);
      if (Object.keys(importedMeta).length) {
        const metaRes = await storage.get(USER_META_KEY);
        const currentMeta = normalizeUserMetaMap(metaRes[USER_META_KEY]);
        for (const user of incoming) {
          if (importedMeta[user]) currentMeta[user] = importedMeta[user];
        }
        await storage.set({ [USER_META_KEY]: currentMeta });
      }
      const data = await storage.get(USER_META_KEY);
      render(updated, normalizeUserMetaMap(data[USER_META_KEY]));
      setImportStatus(`Imported ${incoming.length} users.`);
    } catch (err) {
      setImportStatus('Import failed. Use a JSON array or newline list.');
    } finally {
      importFile.value = '';
    }
  });

  if (exportSafeKeywordsBtn) {
    exportSafeKeywordsBtn.addEventListener('click', async () => {
      const list = await getKeywordList(SAFE_KEYWORDS_KEY);
      downloadJson('reddit-block-safe-keywords.json', { version: 1, type: 'safe_keywords', keywords: list });
      setStatus('Exported keyword whitelist.');
    });
  }

  if (importSafeKeywordsBtn && importSafeKeywordsFile) {
    importSafeKeywordsBtn.addEventListener('click', () => importSafeKeywordsFile.click());
    importSafeKeywordsFile.addEventListener('change', async () => {
      const file = importSafeKeywordsFile.files && importSafeKeywordsFile.files[0];
      if (!file) return;
      try {
        const text = await readFileText(file);
        const incoming = parseImportedKeywordEntries(text);
        const existing = await getKeywordList(SAFE_KEYWORDS_KEY);
        const updated = await setKeywordList(SAFE_KEYWORDS_KEY, existing.concat(incoming));
        renderKeywords(safeKeywordListEl, safeKeywordEmptyEl, updated, SAFE_KEYWORDS_KEY);
        setStatus(`Imported ${incoming.length} keyword whitelist entries.`);
      } catch (err) {
        setStatus('Keyword whitelist import failed.');
      } finally {
        importSafeKeywordsFile.value = '';
      }
    });
  }

  if (exportHideKeywordsBtn) {
    exportHideKeywordsBtn.addEventListener('click', async () => {
      const list = await getKeywordList(HIDE_KEYWORDS_KEY);
      downloadJson('reddit-block-hide-keywords.json', { version: 1, type: 'hide_keywords', keywords: list });
      setStatus('Exported hide-only keywords.');
    });
  }

  if (importHideKeywordsBtn && importHideKeywordsFile) {
    importHideKeywordsBtn.addEventListener('click', () => importHideKeywordsFile.click());
    importHideKeywordsFile.addEventListener('change', async () => {
      const file = importHideKeywordsFile.files && importHideKeywordsFile.files[0];
      if (!file) return;
      try {
        const text = await readFileText(file);
        const incoming = parseImportedKeywordEntries(text);
        const existing = await getKeywordList(HIDE_KEYWORDS_KEY);
        const updated = await setKeywordList(HIDE_KEYWORDS_KEY, existing.concat(incoming));
        renderKeywords(hideKeywordListEl, hideKeywordEmptyEl, updated, HIDE_KEYWORDS_KEY);
        setStatus(`Imported ${incoming.length} hide-only keywords.`);
      } catch (err) {
        setStatus('Hide-only keyword import failed.');
      } finally {
        importHideKeywordsFile.value = '';
      }
    });
  }

  if (exportAggressiveKeywordsBtn) {
    exportAggressiveKeywordsBtn.addEventListener('click', async () => {
      const list = await getKeywordList(AGGRESSIVE_KEYWORDS_KEY);
      downloadJson('reddit-block-aggressive-keywords.json', { version: 1, type: 'aggressive_keywords', keywords: list });
      setStatus('Exported auto-block keywords.');
    });
  }

  if (importAggressiveKeywordsBtn && importAggressiveKeywordsFile) {
    importAggressiveKeywordsBtn.addEventListener('click', () => importAggressiveKeywordsFile.click());
    importAggressiveKeywordsFile.addEventListener('change', async () => {
      const file = importAggressiveKeywordsFile.files && importAggressiveKeywordsFile.files[0];
      if (!file) return;
      try {
        const text = await readFileText(file);
        const incoming = parseImportedKeywordEntries(text);
        const existing = await getKeywordList(AGGRESSIVE_KEYWORDS_KEY);
        const updated = await setKeywordList(AGGRESSIVE_KEYWORDS_KEY, existing.concat(incoming));
        renderKeywords(aggressiveKeywordListEl, aggressiveKeywordEmptyEl, updated, AGGRESSIVE_KEYWORDS_KEY);
        setStatus(`Imported ${incoming.length} auto-block keywords.`);
      } catch (err) {
        setStatus('Auto-block keyword import failed.');
      } finally {
        importAggressiveKeywordsFile.value = '';
      }
    });
  }

  if (exportBlockedSubsBtn) {
    exportBlockedSubsBtn.addEventListener('click', async () => {
      const list = await getBlockedSubs();
      downloadJson('reddit-block-subreddits.json', { version: 1, type: 'blocked_subreddits', subs: list });
      setStatus('Exported blocked subreddits.');
    });
  }

  if (importBlockedSubsBtn && importBlockedSubsFile) {
    importBlockedSubsBtn.addEventListener('click', () => importBlockedSubsFile.click());
    importBlockedSubsFile.addEventListener('change', async () => {
      const file = importBlockedSubsFile.files && importBlockedSubsFile.files[0];
      if (!file) return;
      try {
        const text = await readFileText(file);
        const incoming = parseImportedStringList(text, normalizeSub);
        const existing = await getBlockedSubs();
        const updated = await setBlockedSubs(existing.concat(incoming));
        renderSubs(updated);
        setStatus(`Imported ${incoming.length} blocked subreddits.`);
      } catch (err) {
        setStatus('Blocked subreddit import failed.');
      } finally {
        importBlockedSubsFile.value = '';
      }
    });
  }

  if (exportWhitelistSubsBtn) {
    exportWhitelistSubsBtn.addEventListener('click', async () => {
      const list = await getWhitelistedSubs();
      downloadJson('reddit-block-whitelist-subreddits.json', { version: 1, type: 'whitelisted_subreddits', subs: list });
      setStatus('Exported whitelisted subreddits.');
    });
  }

  if (importWhitelistSubsBtn && importWhitelistSubsFile) {
    importWhitelistSubsBtn.addEventListener('click', () => importWhitelistSubsFile.click());
    importWhitelistSubsFile.addEventListener('change', async () => {
      const file = importWhitelistSubsFile.files && importWhitelistSubsFile.files[0];
      if (!file) return;
      try {
        const text = await readFileText(file);
        const incoming = parseImportedStringList(text, normalizeSub);
        const existing = await getWhitelistedSubs();
        const updated = await setWhitelistedSubs(existing.concat(incoming));
        renderWhitelistSubs(updated);
        setStatus(`Imported ${incoming.length} whitelisted subreddits.`);
      } catch (err) {
        setStatus('Whitelisted subreddit import failed.');
      } finally {
        importWhitelistSubsFile.value = '';
      }
    });
  }

  if (exportSuspiciousUsersBtn) {
    exportSuspiciousUsersBtn.addEventListener('click', async () => {
      const entries = await getSuspiciousList();
      downloadJson('reddit-block-suspicious-users.json', { version: 1, type: 'suspicious_users', users: entries });
      setStatus('Exported suspicious users.');
    });
  }

  if (importSuspiciousUsersBtn && importSuspiciousUsersFile) {
    importSuspiciousUsersBtn.addEventListener('click', () => importSuspiciousUsersFile.click());
    importSuspiciousUsersFile.addEventListener('change', async () => {
      const file = importSuspiciousUsersFile.files && importSuspiciousUsersFile.files[0];
      if (!file) return;
      try {
        const text = await readFileText(file);
        const parsed = JSON.parse(text);
        const incoming = normalizeSuspiciousEntries(extractObjectPayload(parsed, ['users', 'entries']) || {});
        const existing = await getSuspiciousList();
        const updated = await setSuspiciousList(Object.assign({}, existing, incoming));
        renderSuspiciousList(updated);
        setStatus(`Imported ${Object.keys(incoming).length} suspicious users.`);
      } catch (err) {
        setStatus('Suspicious user import failed.');
      } finally {
        importSuspiciousUsersFile.value = '';
      }
    });
  }

  if (hideKeywordForm && hideKeywordInput) {
    setRegexToggleButton(hideKeywordRegexToggleBtn, hideKeywordRegexMode);
    if (hideKeywordRegexToggleBtn) {
      hideKeywordRegexToggleBtn.addEventListener('click', (event) => {
        event.preventDefault();
        event.stopPropagation();
        hideKeywordRegexMode = !hideKeywordRegexMode;
        setRegexToggleButton(hideKeywordRegexToggleBtn, hideKeywordRegexMode);
      });
    }
    hideKeywordForm.addEventListener('submit', async (event) => {
      event.preventDefault();
      const entry = {
        value: normalizeKeywordValue(hideKeywordInput.value, hideKeywordRegexMode),
        regex: hideKeywordRegexMode
      };
      if (!entry.value) return;
      if (entry.regex && !isValidRegexPattern(entry.value)) {
        setStatus('Invalid regular expression.');
        return;
      }
      const list = await getKeywordList(HIDE_KEYWORDS_KEY);
      if (!list.some((keyword) => keywordEntryKey(keyword) === keywordEntryKey(entry))) list.push(entry);
      const updated = await setKeywordList(HIDE_KEYWORDS_KEY, list);
      renderKeywords(hideKeywordListEl, hideKeywordEmptyEl, updated, HIDE_KEYWORDS_KEY);
      hideKeywordInput.value = '';
      setStatus('');
    });
  }

  if (hideKeywordClearBtn) {
    hideKeywordClearBtn.addEventListener('click', async () => {
      const updated = await setKeywordList(HIDE_KEYWORDS_KEY, []);
      renderKeywords(hideKeywordListEl, hideKeywordEmptyEl, updated, HIDE_KEYWORDS_KEY);
    });
  }

  if (safeKeywordForm && safeKeywordInput) {
    setRegexToggleButton(safeKeywordRegexToggleBtn, safeKeywordRegexMode);
    if (safeKeywordRegexToggleBtn) {
      safeKeywordRegexToggleBtn.addEventListener('click', (event) => {
        event.preventDefault();
        event.stopPropagation();
        safeKeywordRegexMode = !safeKeywordRegexMode;
        setRegexToggleButton(safeKeywordRegexToggleBtn, safeKeywordRegexMode);
      });
    }
    safeKeywordForm.addEventListener('submit', async (event) => {
      event.preventDefault();
      const entry = {
        value: normalizeKeywordValue(safeKeywordInput.value, safeKeywordRegexMode),
        regex: safeKeywordRegexMode
      };
      if (!entry.value) return;
      if (entry.regex && !isValidRegexPattern(entry.value)) {
        setStatus('Invalid regular expression.');
        return;
      }
      const list = await getKeywordList(SAFE_KEYWORDS_KEY);
      if (!list.some((keyword) => keywordEntryKey(keyword) === keywordEntryKey(entry))) list.push(entry);
      const updated = await setKeywordList(SAFE_KEYWORDS_KEY, list);
      renderKeywords(safeKeywordListEl, safeKeywordEmptyEl, updated, SAFE_KEYWORDS_KEY);
      safeKeywordInput.value = '';
      setStatus('');
    });
  }

  if (safeKeywordClearBtn) {
    safeKeywordClearBtn.addEventListener('click', async () => {
      const updated = await setKeywordList(SAFE_KEYWORDS_KEY, []);
      renderKeywords(safeKeywordListEl, safeKeywordEmptyEl, updated, SAFE_KEYWORDS_KEY);
    });
  }

  if (aggressiveKeywordForm && aggressiveKeywordInput) {
    setRegexToggleButton(aggressiveKeywordRegexToggleBtn, aggressiveKeywordRegexMode);
    if (aggressiveKeywordRegexToggleBtn) {
      aggressiveKeywordRegexToggleBtn.addEventListener('click', (event) => {
        event.preventDefault();
        event.stopPropagation();
        aggressiveKeywordRegexMode = !aggressiveKeywordRegexMode;
        setRegexToggleButton(aggressiveKeywordRegexToggleBtn, aggressiveKeywordRegexMode);
      });
    }
    aggressiveKeywordForm.addEventListener('submit', async (event) => {
      event.preventDefault();
      const entry = {
        value: normalizeKeywordValue(aggressiveKeywordInput.value, aggressiveKeywordRegexMode),
        regex: aggressiveKeywordRegexMode
      };
      if (!entry.value) return;
      if (entry.regex && !isValidRegexPattern(entry.value)) {
        setStatus('Invalid regular expression.');
        return;
      }
      const list = await getKeywordList(AGGRESSIVE_KEYWORDS_KEY);
      if (!list.some((keyword) => keywordEntryKey(keyword) === keywordEntryKey(entry))) list.push(entry);
      const updated = await setKeywordList(AGGRESSIVE_KEYWORDS_KEY, list);
      renderKeywords(aggressiveKeywordListEl, aggressiveKeywordEmptyEl, updated, AGGRESSIVE_KEYWORDS_KEY);
      aggressiveKeywordInput.value = '';
      setStatus('');
    });
  }

  if (aggressiveKeywordClearBtn) {
    aggressiveKeywordClearBtn.addEventListener('click', async () => {
      const updated = await setKeywordList(AGGRESSIVE_KEYWORDS_KEY, []);
      renderKeywords(aggressiveKeywordListEl, aggressiveKeywordEmptyEl, updated, AGGRESSIVE_KEYWORDS_KEY);
    });
  }

  subForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    const raw = subInput.value;
    const sub = normalizeSub(raw);
    if (!sub) return;
    const list = await getBlockedSubs();
    if (!list.includes(sub)) list.push(sub);
    const updated = await setBlockedSubs(list);
    renderSubs(updated);
    subInput.value = '';
  });

  subClearBtn.addEventListener('click', async () => {
    const updated = await setBlockedSubs([]);
    renderSubs(updated);
  });

  if (whitelistSubForm && whitelistSubInput) {
    whitelistSubForm.addEventListener('submit', async (event) => {
      event.preventDefault();
      const sub = normalizeSub(whitelistSubInput.value);
      if (!sub) return;
      const list = await getWhitelistedSubs();
      if (!list.includes(sub)) list.push(sub);
      const updated = await setWhitelistedSubs(list);
      renderWhitelistSubs(updated);
      whitelistSubInput.value = '';
    });
  }

  if (whitelistSubClearBtn) {
    whitelistSubClearBtn.addEventListener('click', async () => {
      const updated = await setWhitelistedSubs([]);
      renderWhitelistSubs(updated);
    });
  }

  if (suspiciousModeInput && suspiciousThresholdInput) {
    suspiciousModeInput.addEventListener('change', async () => {
      const updated = await setSuspiciousSettings(
        suspiciousModeInput.checked,
        Number(suspiciousThresholdInput.value) || 2
      );
      suspiciousModeInput.checked = updated.enabled;
      suspiciousThresholdInput.value = updated.threshold;
    });

    suspiciousThresholdInput.addEventListener('change', async () => {
      const updated = await setSuspiciousSettings(
        suspiciousModeInput.checked,
        Number(suspiciousThresholdInput.value) || 2
      );
      suspiciousThresholdInput.value = updated.threshold;
    });
  }

  if (suspiciousClearBtn) {
    suspiciousClearBtn.addEventListener('click', async () => {
      const updated = await setSuspiciousList({});
      renderSuspiciousList(updated);
    });
  }

  if (hideBlockedPostsCompletelyInput && blockDecayEnabledInput && blockDecayDaysInput) {
    hideBlockedPostsCompletelyInput.addEventListener('change', async () => {
      const updated = await setPostDisplaySettings(
        hideBlockedPostsCompletelyInput.checked,
        blockDecayEnabledInput.checked,
        Number(blockDecayDaysInput.value) || 30
      );
      hideBlockedPostsCompletelyInput.checked = updated.hideBlockedPostsCompletely;
      blockDecayEnabledInput.checked = updated.decayEnabled;
      blockDecayDaysInput.value = updated.decayDays;
    });

    blockDecayEnabledInput.addEventListener('change', async () => {
      const updated = await setPostDisplaySettings(
        hideBlockedPostsCompletelyInput.checked,
        blockDecayEnabledInput.checked,
        Number(blockDecayDaysInput.value) || 30
      );
      await pruneExpiredBlockedUsers();
      hideBlockedPostsCompletelyInput.checked = updated.hideBlockedPostsCompletely;
      blockDecayEnabledInput.checked = updated.decayEnabled;
      blockDecayDaysInput.value = updated.decayDays;
    });

    blockDecayDaysInput.addEventListener('change', async () => {
      const updated = await setPostDisplaySettings(
        hideBlockedPostsCompletelyInput.checked,
        blockDecayEnabledInput.checked,
        Number(blockDecayDaysInput.value) || 30
      );
      await pruneExpiredBlockedUsers();
      blockDecayDaysInput.value = updated.decayDays;
    });
  }

  if (sweepUiAvailable) {
    autoSweepInput.addEventListener('change', async () => {
      const enabled = autoSweepInput.checked;
      const delaySeconds = Number(sweepDelayInput.value) || 3;
      const updated = await setSweepSettings(
        enabled,
        delaySeconds * 1000,
        sweepScoreExceptionEnabledInput && sweepScoreExceptionEnabledInput.checked,
        sweepScoreMinInput ? Number(sweepScoreMinInput.value) || -1 : -1,
        sweepScoreMaxInput ? Number(sweepScoreMaxInput.value) || 1 : 1,
        sweepMaxPostAgeHoursInput ? Number(sweepMaxPostAgeHoursInput.value) || 0 : 0
      );
      autoSweepInput.checked = updated.enabled;
      sweepDelayInput.value = Math.round(updated.delayMs / 1000);
      if (sweepScoreExceptionEnabledInput) sweepScoreExceptionEnabledInput.checked = updated.scoreExceptionEnabled;
      if (sweepScoreMinInput) sweepScoreMinInput.value = updated.scoreMin;
      if (sweepScoreMaxInput) sweepScoreMaxInput.value = updated.scoreMax;
      if (sweepMaxPostAgeHoursInput) sweepMaxPostAgeHoursInput.value = updated.maxPostAgeHours;
    });

    sweepDelayInput.addEventListener('change', async () => {
      const delaySeconds = Number(sweepDelayInput.value) || 3;
      const updated = await setSweepSettings(
        autoSweepInput.checked,
        delaySeconds * 1000,
        sweepScoreExceptionEnabledInput && sweepScoreExceptionEnabledInput.checked,
        sweepScoreMinInput ? Number(sweepScoreMinInput.value) || -1 : -1,
        sweepScoreMaxInput ? Number(sweepScoreMaxInput.value) || 1 : 1,
        sweepMaxPostAgeHoursInput ? Number(sweepMaxPostAgeHoursInput.value) || 0 : 0
      );
      sweepDelayInput.value = Math.round(updated.delayMs / 1000);
    });

    if (sweepScoreExceptionEnabledInput) {
      sweepScoreExceptionEnabledInput.addEventListener('change', async () => {
        const updated = await setSweepSettings(
          autoSweepInput.checked,
          (Number(sweepDelayInput.value) || 3) * 1000,
          sweepScoreExceptionEnabledInput.checked,
          sweepScoreMinInput ? Number(sweepScoreMinInput.value) || -1 : -1,
          sweepScoreMaxInput ? Number(sweepScoreMaxInput.value) || 1 : 1,
          sweepMaxPostAgeHoursInput ? Number(sweepMaxPostAgeHoursInput.value) || 0 : 0
        );
        sweepScoreExceptionEnabledInput.checked = updated.scoreExceptionEnabled;
      });
    }

    if (sweepScoreMinInput) {
      sweepScoreMinInput.addEventListener('change', async () => {
        const updated = await setSweepSettings(
          autoSweepInput.checked,
          (Number(sweepDelayInput.value) || 3) * 1000,
          sweepScoreExceptionEnabledInput && sweepScoreExceptionEnabledInput.checked,
          Number(sweepScoreMinInput.value) || -1,
          sweepScoreMaxInput ? Number(sweepScoreMaxInput.value) || 1 : 1,
          sweepMaxPostAgeHoursInput ? Number(sweepMaxPostAgeHoursInput.value) || 0 : 0
        );
        sweepScoreMinInput.value = updated.scoreMin;
        if (sweepScoreMaxInput) sweepScoreMaxInput.value = updated.scoreMax;
      });
    }

    if (sweepScoreMaxInput) {
      sweepScoreMaxInput.addEventListener('change', async () => {
        const updated = await setSweepSettings(
          autoSweepInput.checked,
          (Number(sweepDelayInput.value) || 3) * 1000,
          sweepScoreExceptionEnabledInput && sweepScoreExceptionEnabledInput.checked,
          sweepScoreMinInput ? Number(sweepScoreMinInput.value) || -1 : -1,
          Number(sweepScoreMaxInput.value) || 1,
          sweepMaxPostAgeHoursInput ? Number(sweepMaxPostAgeHoursInput.value) || 0 : 0
        );
        if (sweepScoreMinInput) sweepScoreMinInput.value = updated.scoreMin;
        sweepScoreMaxInput.value = updated.scoreMax;
      });
    }

    if (sweepMaxPostAgeHoursInput) {
      sweepMaxPostAgeHoursInput.addEventListener('change', async () => {
        const updated = await setSweepSettings(
          autoSweepInput.checked,
          (Number(sweepDelayInput.value) || 3) * 1000,
          sweepScoreExceptionEnabledInput && sweepScoreExceptionEnabledInput.checked,
          sweepScoreMinInput ? Number(sweepScoreMinInput.value) || -1 : -1,
          sweepScoreMaxInput ? Number(sweepScoreMaxInput.value) || 1 : 1,
          Number(sweepMaxPostAgeHoursInput.value) || 0
        );
        sweepMaxPostAgeHoursInput.value = updated.maxPostAgeHours;
      });
    }
  }

  if (scanUiAvailable) {
    autoScanInput.addEventListener('change', async () => {
      const enabled = autoScanInput.checked;
      const posts = Number(scanPostsInput.value) || 10;
      const throttleSeconds = Number(scanThrottleInput.value) || 2;
      const intervalMinutes = Number(scanIntervalInput.value) || 10080;
      const updated = await setScanSettings(enabled, posts, throttleSeconds * 1000, intervalMinutes);
      autoScanInput.checked = updated.enabled;
      scanPostsInput.value = updated.postsPerSub;
      scanThrottleInput.value = Math.round(updated.throttleMs / 1000);
      scanIntervalInput.value = Math.round(updated.intervalMinutes);
      if (!updated.enabled) {
        requestStopScan();
      }
    });

    scanPostsInput.addEventListener('change', async () => {
      const updated = await setScanSettings(
        autoScanInput.checked,
        Number(scanPostsInput.value) || 10,
        (Number(scanThrottleInput.value) || 2) * 1000,
        Number(scanIntervalInput.value) || 10080
      );
      scanPostsInput.value = updated.postsPerSub;
    });

    scanThrottleInput.addEventListener('change', async () => {
      const updated = await setScanSettings(
        autoScanInput.checked,
        Number(scanPostsInput.value) || 10,
        (Number(scanThrottleInput.value) || 2) * 1000,
        Number(scanIntervalInput.value) || 10080
      );
      scanThrottleInput.value = Math.round(updated.throttleMs / 1000);
    });

    scanIntervalInput.addEventListener('change', async () => {
      const updated = await setScanSettings(
        autoScanInput.checked,
        Number(scanPostsInput.value) || 10,
        (Number(scanThrottleInput.value) || 2) * 1000,
        Number(scanIntervalInput.value) || 10080
      );
      scanIntervalInput.value = Math.round(updated.intervalMinutes);
    });

    scanNowBtn.addEventListener('click', () => {
      scanStatusEl.textContent = 'Starting scan...';
      api.runtime.sendMessage({ type: 'rbu-scan-now' }, (response) => {
        if (api.runtime.lastError) {
          scanStatusEl.textContent = 'Scan failed to start.';
          return;
        }
        if (response && response.status === 'running') {
          scanStatusEl.textContent = 'Scan already running...';
          return;
        }
        scanStatusEl.textContent = 'Scan started...';
      });
    });
  }

  api.storage.onChanged.addListener((changes) => {
    if (changes[USER_META_KEY]) {
      blockedUserMetaCache = normalizeUserMetaMap(changes[USER_META_KEY].newValue || {});
      render(blockedUsersCache, blockedUserMetaCache);
    }
    if (changes[STORAGE_KEY]) {
      const next = changes[STORAGE_KEY].newValue || [];
      render(next.map(normalize).filter(Boolean), blockedUserMetaCache);
    }
    if (changes[SUSPICIOUS_USERS_KEY]) {
      renderSuspiciousList(normalizeSuspiciousEntries(changes[SUSPICIOUS_USERS_KEY].newValue || {}));
    }
    if (changes[LOG_KEY]) {
      renderLog(normalizeLogEntries(changes[LOG_KEY].newValue || []));
    }
    if (changes[SAFE_KEYWORDS_KEY]) {
      const next = changes[SAFE_KEYWORDS_KEY].newValue || [];
      renderKeywords(
        safeKeywordListEl,
        safeKeywordEmptyEl,
        normalizeKeywordEntries(next),
        SAFE_KEYWORDS_KEY
      );
    }
    if (changes[HIDE_KEYWORDS_KEY]) {
      const next = changes[HIDE_KEYWORDS_KEY].newValue || [];
      renderKeywords(
        hideKeywordListEl,
        hideKeywordEmptyEl,
        normalizeKeywordEntries(next),
        HIDE_KEYWORDS_KEY
      );
    }
    if (changes[AGGRESSIVE_KEYWORDS_KEY]) {
      const next = changes[AGGRESSIVE_KEYWORDS_KEY].newValue || [];
      renderKeywords(
        aggressiveKeywordListEl,
        aggressiveKeywordEmptyEl,
        normalizeKeywordEntries(next),
        AGGRESSIVE_KEYWORDS_KEY
      );
    }
    if (changes[SUB_STORAGE_KEY]) {
      const next = changes[SUB_STORAGE_KEY].newValue || [];
      renderSubs(next.map(normalizeSub).filter(Boolean));
    }
    if (changes[SUB_WHITELIST_KEY]) {
      const next = changes[SUB_WHITELIST_KEY].newValue || [];
      renderWhitelistSubs(next.map(normalizeSub).filter(Boolean));
    }
    if (changes[SUSPICIOUS_MODE_KEY] && suspiciousModeInput) {
      suspiciousModeInput.checked = Boolean(changes[SUSPICIOUS_MODE_KEY].newValue);
    }
    if (changes[SUSPICIOUS_THRESHOLD_KEY] && suspiciousThresholdInput) {
      suspiciousThresholdInput.value = clampNumber(changes[SUSPICIOUS_THRESHOLD_KEY].newValue, 1, 100, 2);
    }
    if (changes[HIDE_BLOCKED_POSTS_COMPLETELY_KEY] && hideBlockedPostsCompletelyInput) {
      hideBlockedPostsCompletelyInput.checked = Boolean(changes[HIDE_BLOCKED_POSTS_COMPLETELY_KEY].newValue);
    }
    if (changes[BLOCK_DECAY_ENABLED_KEY] && blockDecayEnabledInput) {
      blockDecayEnabledInput.checked = Boolean(changes[BLOCK_DECAY_ENABLED_KEY].newValue);
    }
    if (changes[BLOCK_DECAY_DAYS_KEY] && blockDecayDaysInput) {
      blockDecayDaysInput.value = clampNumber(changes[BLOCK_DECAY_DAYS_KEY].newValue, 1, 3650, 30);
    }
    if (
      sweepUiAvailable &&
      (changes[SWEEP_KEY] ||
        changes[SWEEP_DELAY_KEY] ||
        changes[SWEEP_SCORE_EXCEPTION_ENABLED_KEY] ||
        changes[SWEEP_SCORE_MIN_KEY] ||
        changes[SWEEP_SCORE_MAX_KEY] ||
        changes[SWEEP_MAX_POST_AGE_HOURS_KEY])
    ) {
      const enabled = changes[SWEEP_KEY] ? Boolean(changes[SWEEP_KEY].newValue) : autoSweepInput.checked;
      const delayMs = changes[SWEEP_DELAY_KEY]
        ? Number(changes[SWEEP_DELAY_KEY].newValue) || 3000
        : Number(sweepDelayInput.value || 3) * 1000;
      autoSweepInput.checked = enabled;
      sweepDelayInput.value = Math.round(delayMs / 1000);
      if (sweepScoreExceptionEnabledInput) {
        sweepScoreExceptionEnabledInput.checked = changes[SWEEP_SCORE_EXCEPTION_ENABLED_KEY]
          ? Boolean(changes[SWEEP_SCORE_EXCEPTION_ENABLED_KEY].newValue)
          : sweepScoreExceptionEnabledInput.checked;
      }
      if (sweepScoreMinInput) {
        sweepScoreMinInput.value = changes[SWEEP_SCORE_MIN_KEY]
          ? clampNumber(changes[SWEEP_SCORE_MIN_KEY].newValue, -1000000, 1000000, -1)
          : Number(sweepScoreMinInput.value) || -1;
      }
      if (sweepScoreMaxInput) {
        sweepScoreMaxInput.value = changes[SWEEP_SCORE_MAX_KEY]
          ? clampNumber(changes[SWEEP_SCORE_MAX_KEY].newValue, -1000000, 1000000, 1)
          : Number(sweepScoreMaxInput.value) || 1;
      }
      if (sweepMaxPostAgeHoursInput) {
        sweepMaxPostAgeHoursInput.value = changes[SWEEP_MAX_POST_AGE_HOURS_KEY]
          ? clampNumber(changes[SWEEP_MAX_POST_AGE_HOURS_KEY].newValue, 0, 87600, 0)
          : Number(sweepMaxPostAgeHoursInput.value) || 0;
      }
    }
    if (
      scanUiAvailable &&
      (changes[SCAN_ENABLED_KEY] || changes[SCAN_POSTS_KEY] || changes[SCAN_THROTTLE_KEY] || changes[SCAN_INTERVAL_KEY])
    ) {
      const enabled = changes[SCAN_ENABLED_KEY] ? Boolean(changes[SCAN_ENABLED_KEY].newValue) : autoScanInput.checked;
      const posts = changes[SCAN_POSTS_KEY] ? Number(changes[SCAN_POSTS_KEY].newValue) || 10 : Number(scanPostsInput.value) || 10;
      const throttleMs = changes[SCAN_THROTTLE_KEY]
        ? Number(changes[SCAN_THROTTLE_KEY].newValue) || 2000
        : (Number(scanThrottleInput.value) || 2) * 1000;
      const intervalMinutes = changes[SCAN_INTERVAL_KEY]
        ? Number(changes[SCAN_INTERVAL_KEY].newValue) || 10080
        : Number(scanIntervalInput.value) || 10080;

      autoScanInput.checked = enabled;
      scanPostsInput.value = posts;
      scanThrottleInput.value = Math.round(throttleMs / 1000);
      scanIntervalInput.value = Math.round(intervalMinutes);
    }
    if (scanUiAvailable && (changes[SCAN_STATUS_KEY] || changes[SCAN_LAST_KEY] || changes[SCAN_ERROR_KEY])) {
      const status = changes[SCAN_STATUS_KEY] ? changes[SCAN_STATUS_KEY].newValue : null;
      const lastRun = changes[SCAN_LAST_KEY] ? changes[SCAN_LAST_KEY].newValue : null;
      const error = changes[SCAN_ERROR_KEY] ? changes[SCAN_ERROR_KEY].newValue : null;
      renderScanStatus(status, lastRun, error);
    }
  });

  (async () => {
    await pruneExpiredBlockedUsers();
    const list = await getBlockedList();
    const blockedMetaRes = await storage.get(USER_META_KEY);
    render(list, normalizeUserMetaMap(blockedMetaRes[USER_META_KEY]));
    const safeKeywordList = await getKeywordList(SAFE_KEYWORDS_KEY);
    renderKeywords(safeKeywordListEl, safeKeywordEmptyEl, safeKeywordList, SAFE_KEYWORDS_KEY);
    const logEntries = await storage.get(LOG_KEY);
    renderLog(normalizeLogEntries(logEntries[LOG_KEY]));
    const hideKeywordList = await getKeywordList(HIDE_KEYWORDS_KEY);
    renderKeywords(hideKeywordListEl, hideKeywordEmptyEl, hideKeywordList, HIDE_KEYWORDS_KEY);
    const aggressiveKeywordList = await getKeywordList(AGGRESSIVE_KEYWORDS_KEY);
    renderKeywords(
      aggressiveKeywordListEl,
      aggressiveKeywordEmptyEl,
      aggressiveKeywordList,
      AGGRESSIVE_KEYWORDS_KEY
    );
    const subs = await getBlockedSubs();
    renderSubs(subs);
    const whitelistSubs = await getWhitelistedSubs();
    renderWhitelistSubs(whitelistSubs);
    const suspicious = await getSuspiciousList();
    renderSuspiciousList(suspicious);
    const suspiciousSettings = await getSuspiciousSettings();
    if (suspiciousModeInput) suspiciousModeInput.checked = suspiciousSettings.enabled;
    if (suspiciousThresholdInput) suspiciousThresholdInput.value = suspiciousSettings.threshold;
    const postDisplay = await getPostDisplaySettings();
    if (hideBlockedPostsCompletelyInput) {
      hideBlockedPostsCompletelyInput.checked = postDisplay.hideBlockedPostsCompletely;
    }
    if (blockDecayEnabledInput) blockDecayEnabledInput.checked = postDisplay.decayEnabled;
    if (blockDecayDaysInput) blockDecayDaysInput.value = postDisplay.decayDays;
    if (sweepUiAvailable) {
      const sweep = await getSweepSettings();
      autoSweepInput.checked = sweep.enabled;
      sweepDelayInput.value = Math.round((sweep.delayMs || 3000) / 1000);
      if (sweepScoreExceptionEnabledInput) sweepScoreExceptionEnabledInput.checked = sweep.scoreExceptionEnabled;
      if (sweepScoreMinInput) sweepScoreMinInput.value = sweep.scoreMin;
      if (sweepScoreMaxInput) sweepScoreMaxInput.value = sweep.scoreMax;
      if (sweepMaxPostAgeHoursInput) sweepMaxPostAgeHoursInput.value = sweep.maxPostAgeHours;
    }
    if (scanUiAvailable) {
      const scan = await getScanSettings();
      autoScanInput.checked = scan.enabled;
      scanPostsInput.value = scan.postsPerSub;
      scanThrottleInput.value = Math.round(scan.throttleMs / 1000);
      scanIntervalInput.value = Math.round(scan.intervalMinutes);
      const scanState = await storage.get([SCAN_STATUS_KEY, SCAN_LAST_KEY, SCAN_ERROR_KEY]);
      renderScanStatus(scanState[SCAN_STATUS_KEY], scanState[SCAN_LAST_KEY], scanState[SCAN_ERROR_KEY]);
    }
  })();
})();
