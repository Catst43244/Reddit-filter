(() => {
  'use strict';

  const api = typeof browser !== 'undefined' ? browser : chrome;
  if (!api || !api.storage) {
    console.warn('[Reddit Block Button] Storage API unavailable.');
    return;
  }

  const STORAGE_KEY = 'rbuBlockedUsers';
  const SUB_STORAGE_KEY = 'rbuBlockedSubs';
  const SUB_WHITELIST_KEY = 'rbuWhitelistedSubs';
  const HIDE_KEYWORDS_KEY = 'rbuHideKeywords';
  const SAFE_KEYWORDS_KEY = 'rbuSafeKeywords';
  const AGGRESSIVE_KEYWORDS_KEY = 'rbuAggressiveKeywords';
  const LOG_KEY = 'rbuEventLog';
  const SWEEP_KEY = 'rbuAutoSweepEnabled';
  const SWEEP_DELAY_KEY = 'rbuAutoSweepDelayMs';
  const SUSPICIOUS_MODE_KEY = 'rbuSuspiciousModeEnabled';
  const SUSPICIOUS_THRESHOLD_KEY = 'rbuSuspiciousThreshold';
  const SUSPICIOUS_USERS_KEY = 'rbuSuspiciousUsers';
  const USER_META_KEY = 'rbuUserMeta';
  const HIDE_BLOCKED_POSTS_COMPLETELY_KEY = 'rbuHideBlockedPostsCompletely';
  const BLOCK_DECAY_ENABLED_KEY = 'rbuBlockDecayEnabled';
  const BLOCK_DECAY_DAYS_KEY = 'rbuBlockDecayDays';
  const SWEEP_SCORE_EXCEPTION_ENABLED_KEY = 'rbuSweepScoreExceptionEnabled';
  const SWEEP_SCORE_MIN_KEY = 'rbuSweepScoreMin';
  const SWEEP_SCORE_MAX_KEY = 'rbuSweepScoreMax';
  const SWEEP_MAX_POST_AGE_HOURS_KEY = 'rbuSweepMaxPostAgeHours';
  const SWEEP_QUERY_KEY = 'rbu_sweep';
  const HIDDEN_CLASS = 'rbu-hidden';
  const DOUBLE_QUOTE_CHARS = /[\u0022\u201c\u201d\u201e\u201f\u00ab\u00bb\u301d\u301e\u301f\u2033\uff02]/g;
  const SWEEP_MEDIA_SELECTOR = [
    'img',
    'picture',
    'video',
    'audio',
    'source',
    'iframe',
    'embed',
    'object',
    'faceplate-img',
    'shreddit-player',
    'shreddit-player-2',
    'gallery-carousel'
  ].join(',');

  const CONTAINER_SELECTOR = [
    'shreddit-post',
    'shreddit-comment',
    '[data-testid="post-container"]',
    '[data-test-id="comment"]',
    'div.Post',
    'div.comment',
    'div.thing',
    'div.thing.comment',
    'div.thing.link'
  ].join(',');

  const REDDIT_POST_SELECTOR = [
    'shreddit-post',
    '[data-testid="post-container"]',
    'div.Post',
    'article[post-id]',
    'article[data-testid="post-container"]',
    'article[data-adclicklocation="background"]'
  ].join(',');

  const AUTHOR_SELECTORS = [
    'a[data-testid="comment_author_link"]',
    'a[data-testid="post_author_link"]',
    'a[data-click-id="user"]',
    'a.author',
    'p.tagline a.author'
  ];

  const BODY_SELECTORS = [
    '.md',
    '.usertext-body',
    '[data-testid="comment-body"]',
    '[data-click-id="text"]',
    'div[data-testid="post-content"]'
  ];

  const storage = api.storage.local;
  let blocked = new Set();
  let blockedSubs = new Set();
  let whitelistedSubs = new Set();
  let hideKeywords = [];
  let safeKeywords = [];
  let aggressiveKeywords = [];
  let suspiciousModeEnabled = false;
  let suspiciousThreshold = 2;
  let suspiciousUsers = {};
  let userMeta = {};
  let hideBlockedPostsCompletely = false;
  let blockDecayEnabled = false;
  let blockDecayDays = 30;
  let sweepScoreExceptionEnabled = false;
  let sweepScoreMin = -1;
  let sweepScoreMax = 1;
  let sweepMaxPostAgeHours = 0;
  let autoSweepEnabled = false;
  let autoSweepDelayMs = 3000;
  let sweepInProgress = false;
  let sweepReturnTimer = null;
  let sweepRetryTimer = null;
  let sweepCooldownTimer = null;
  let sweepAgeStopActive = false;
  const pendingKeywordBlocks = new Map();
  let flushingKeywordBlocks = false;

  function normalize(name) {
    return (name || '').trim().toLowerCase();
  }

  function normalizeDoubleQuotes(text) {
    return (text || '').replace(DOUBLE_QUOTE_CHARS, '"');
  }

  function clampNumber(value, min, max, fallback) {
    const num = Number(value);
    if (!Number.isFinite(num)) return fallback;
    return Math.min(max, Math.max(min, num));
  }

  function normalizeKeywordValue(value, useRegex) {
    const cleaned = normalizeDoubleQuotes((value || '').trim());
    return useRegex ? cleaned : cleaned.toLowerCase();
  }

  function normalizeKeywordEntry(entry) {
    if (typeof entry === 'string') {
      const value = normalizeKeywordValue(entry, false);
      return value ? { value, regex: false } : null;
    }
    if (!entry || typeof entry !== 'object') return null;
    const regex = Boolean(entry.regex);
    const value = normalizeKeywordValue(entry.value, regex);
    if (!value) return null;
    return { value, regex };
  }

  function normalizeKeywordList(list) {
    const normalized = (Array.isArray(list) ? list : []).map(normalizeKeywordEntry).filter(Boolean);
    const unique = new Map();
    for (const entry of normalized) {
      unique.set(`${entry.regex ? 'regex' : 'text'}:${entry.value}`, entry);
    }
    return Array.from(unique.values());
  }

  function cleanUsername(raw) {
    if (!raw) return null;
    let name = raw.trim();
    if (name.startsWith('u/')) name = name.slice(2);
    if (name.startsWith('/user/')) name = name.replace(/^\/user\//i, '');
    name = name.replace(/\/$/, '');
    return name || null;
  }

  function normalizeUserMetaMap(value) {
    const next = {};
    if (!value || typeof value !== 'object') return next;
    for (const [rawName, rawMeta] of Object.entries(value)) {
      const name = normalize(rawName);
      if (!name || !rawMeta || typeof rawMeta !== 'object') continue;
      next[name] = {
        reasonType: typeof rawMeta.reasonType === 'string' ? rawMeta.reasonType : '',
        reasonLabel: typeof rawMeta.reasonLabel === 'string' ? rawMeta.reasonLabel : '',
        keyword: typeof rawMeta.keyword === 'string' ? rawMeta.keyword : '',
        subreddit: typeof rawMeta.subreddit === 'string' ? normalizeSub(rawMeta.subreddit) : '',
        source: typeof rawMeta.source === 'string' ? rawMeta.source : '',
        blockedAt: rawMeta.blockedAt === undefined ? 0 : clampNumber(rawMeta.blockedAt, 0, Number.MAX_SAFE_INTEGER, 0)
      };
    }
    return next;
  }

  function normalizeSuspiciousMap(value) {
    const next = {};
    if (!value || typeof value !== 'object') return next;
    for (const [rawName, rawEntry] of Object.entries(value)) {
      const name = normalize(rawName);
      if (!name || !rawEntry || typeof rawEntry !== 'object') continue;
      const rawSubs = rawEntry.subreddits && typeof rawEntry.subreddits === 'object' ? rawEntry.subreddits : {};
      const subreddits = {};
      for (const [rawSub, rawCount] of Object.entries(rawSubs)) {
        const sub = normalizeSub(rawSub);
        if (!sub) continue;
        subreddits[sub] = clampNumber(rawCount, 0, 1000000, 0);
      }
      next[name] = {
        count: clampNumber(rawEntry.count, 0, 1000000, 0),
        keywordHits: clampNumber(rawEntry.keywordHits, 0, 1000000, 0),
        subredditHits: clampNumber(rawEntry.subredditHits, 0, 1000000, 0),
        subreddits,
        lastReasonType: typeof rawEntry.lastReasonType === 'string' ? rawEntry.lastReasonType : '',
        lastKeyword: typeof rawEntry.lastKeyword === 'string' ? rawEntry.lastKeyword : '',
        lastSubreddit: typeof rawEntry.lastSubreddit === 'string' ? normalizeSub(rawEntry.lastSubreddit) : '',
        lastSeen: clampNumber(rawEntry.lastSeen, 0, Number.MAX_SAFE_INTEGER, Date.now()),
        lastContent: typeof rawEntry.lastContent === 'string' ? rawEntry.lastContent : '',
        lastHitKey: typeof rawEntry.lastHitKey === 'string' ? rawEntry.lastHitKey : ''
      };
    }
    return next;
  }

  function extractUsernameFromHref(href) {
    if (!href) return null;
    try {
      const url = new URL(href, location.origin);
      const match = url.pathname.match(/^\/user\/([^\/\?#]+)/i);
      if (match) return match[1];
    } catch (err) {
      return null;
    }
    return null;
  }

  async function loadBlocked() {
    const res = await storage.get([
      STORAGE_KEY,
      SUB_STORAGE_KEY,
      SUB_WHITELIST_KEY,
      HIDE_KEYWORDS_KEY,
      SAFE_KEYWORDS_KEY,
      AGGRESSIVE_KEYWORDS_KEY,
      SWEEP_KEY,
      SWEEP_DELAY_KEY,
      SUSPICIOUS_MODE_KEY,
      SUSPICIOUS_THRESHOLD_KEY,
      SUSPICIOUS_USERS_KEY,
      USER_META_KEY,
      HIDE_BLOCKED_POSTS_COMPLETELY_KEY,
      BLOCK_DECAY_ENABLED_KEY,
      BLOCK_DECAY_DAYS_KEY,
      SWEEP_SCORE_EXCEPTION_ENABLED_KEY,
      SWEEP_SCORE_MIN_KEY,
      SWEEP_SCORE_MAX_KEY,
      SWEEP_MAX_POST_AGE_HOURS_KEY
    ]);
    const arr = res && Array.isArray(res[STORAGE_KEY]) ? res[STORAGE_KEY] : [];
    blocked = new Set(arr.map(normalize).filter(Boolean));
    const subs = res && Array.isArray(res[SUB_STORAGE_KEY]) ? res[SUB_STORAGE_KEY] : [];
    blockedSubs = new Set(subs.map(normalizeSub).filter(Boolean));
    const whitelistSubs = res && Array.isArray(res[SUB_WHITELIST_KEY]) ? res[SUB_WHITELIST_KEY] : [];
    whitelistedSubs = new Set(whitelistSubs.map(normalizeSub).filter(Boolean));
    hideKeywords = normalizeKeywordList(res[HIDE_KEYWORDS_KEY]);
    safeKeywords = normalizeKeywordList(res[SAFE_KEYWORDS_KEY]);
    aggressiveKeywords = normalizeKeywordList(res[AGGRESSIVE_KEYWORDS_KEY]);
    suspiciousModeEnabled = Boolean(res[SUSPICIOUS_MODE_KEY]);
    suspiciousThreshold = clampNumber(res[SUSPICIOUS_THRESHOLD_KEY], 1, 100, 2);
    suspiciousUsers = normalizeSuspiciousMap(res[SUSPICIOUS_USERS_KEY]);
    userMeta = normalizeUserMetaMap(res[USER_META_KEY]);
    hideBlockedPostsCompletely = Boolean(res[HIDE_BLOCKED_POSTS_COMPLETELY_KEY]);
    blockDecayEnabled = Boolean(res[BLOCK_DECAY_ENABLED_KEY]);
    blockDecayDays = clampNumber(res[BLOCK_DECAY_DAYS_KEY], 1, 3650, 30);
    sweepScoreExceptionEnabled = Boolean(res[SWEEP_SCORE_EXCEPTION_ENABLED_KEY]);
    sweepScoreMin = clampNumber(res[SWEEP_SCORE_MIN_KEY], -1000000, 1000000, -1);
    sweepScoreMax = clampNumber(res[SWEEP_SCORE_MAX_KEY], -1000000, 1000000, 1);
    sweepMaxPostAgeHours = clampNumber(res[SWEEP_MAX_POST_AGE_HOURS_KEY], 0, 87600, 0);
    autoSweepEnabled = Boolean(res[SWEEP_KEY]);
    const delay = Number(res[SWEEP_DELAY_KEY]);
    if (Number.isFinite(delay) && delay >= 500 && delay <= 30000) {
      autoSweepDelayMs = delay;
    }
    await pruneExpiredBlocks();
  }

  async function saveBlocked() {
    await storage.set({ [STORAGE_KEY]: Array.from(blocked) });
  }

  async function saveUserMeta() {
    await storage.set({ [USER_META_KEY]: userMeta });
  }

  async function saveSuspiciousUsers() {
    await storage.set({ [SUSPICIOUS_USERS_KEY]: suspiciousUsers });
  }

  async function saveBlockedSubs() {
    await storage.set({ [SUB_STORAGE_KEY]: Array.from(blockedSubs).sort() });
  }

  function normalizeSub(name) {
    if (!name) return '';
    let cleaned = name.trim().toLowerCase();
    if (cleaned.startsWith('r/')) cleaned = cleaned.slice(2);
    if (cleaned.startsWith('/r/')) cleaned = cleaned.replace(/^\/r\//i, '');
    cleaned = cleaned.replace(/\/$/, '');
    return cleaned;
  }

  async function blockUser(name) {
    await blockUsersBulk([{ username: name, meta: buildBlockMeta({ reasonType: 'manual' }) }]);
  }

  async function unblockUser(name) {
    const norm = normalize(name);
    if (!norm) return;
    if (blocked.has(norm)) {
      blocked.delete(norm);
      delete userMeta[norm];
      delete suspiciousUsers[norm];
      await saveBlocked();
      await saveUserMeta();
      await saveSuspiciousUsers();
    }
  }

  function buildBlockMeta({ reasonType, keyword, subreddit, source, reasonLabel } = {}) {
    const normalizedSubreddit = normalizeSub(subreddit);
    const label =
      reasonLabel ||
      (reasonType === 'keyword'
        ? `Triggered keyword blocker${keyword ? ` (${formatKeywordForLog(keyword)})` : ''}`
        : reasonType === 'subreddit'
          ? `Participated in blocked subreddit r/${normalizedSubreddit || 'unknown'}`
          : reasonType === 'suspicious'
            ? 'Reached suspicious activity threshold'
            : 'Manual/unknown inclusion');
    return {
      reasonType: reasonType || 'manual',
      reasonLabel: label,
      keyword: keyword ? formatKeywordForLog(keyword) : '',
      subreddit: normalizedSubreddit,
      source: source || '',
      blockedAt: Date.now()
    };
  }

  async function blockUsersBulk(entries) {
    let changed = false;
    const normalizedEntries = Array.isArray(entries) ? entries : [];
    for (const rawEntry of normalizedEntries) {
      const norm = normalize(rawEntry && rawEntry.username ? rawEntry.username : rawEntry);
      if (!norm) continue;
      if (!blocked.has(norm)) {
        blocked.add(norm);
        userMeta[norm] = buildBlockMeta(rawEntry && rawEntry.meta ? rawEntry.meta : { reasonType: 'manual' });
        delete suspiciousUsers[norm];
        changed = true;
      }
    }
    if (changed) {
      await saveBlocked();
      await saveUserMeta();
      await saveSuspiciousUsers();
    }
    return changed;
  }

  async function pruneExpiredBlocks() {
    if (!blockDecayEnabled) return false;
    const ttlMs = blockDecayDays * 24 * 60 * 60 * 1000;
    if (!ttlMs) return false;
    const now = Date.now();
    let changed = false;
    for (const name of Array.from(blocked)) {
      const meta = userMeta[name];
      if (!meta || !meta.blockedAt) continue;
      if (now - meta.blockedAt >= ttlMs) {
        blocked.delete(name);
        delete userMeta[name];
        delete suspiciousUsers[name];
        changed = true;
      }
    }
    if (changed) {
      await saveBlocked();
      await saveUserMeta();
      await saveSuspiciousUsers();
    }
    return changed;
  }

  function formatBlockReason(username, fallbackReason) {
    if (fallbackReason) return fallbackReason;
    const meta = userMeta[normalize(username)];
    if (meta && meta.reasonLabel) return meta.reasonLabel;
    return 'Unknown reason/manual inclusion';
  }

  async function appendLogEntries(entries) {
    if (!entries.length) return;
    const res = await storage.get(LOG_KEY);
    const current = res && Array.isArray(res[LOG_KEY]) ? res[LOG_KEY] : [];
    const next = entries.concat(current).slice(0, 200);
    await storage.set({ [LOG_KEY]: next });
  }

  function formatKeywordForLog(keyword) {
    if (!keyword || !keyword.value) return '';
    return keyword.regex ? `/${keyword.value}/` : keyword.value;
  }

  function normalizeLoggedContent(text) {
    const cleaned = (text || '').replace(/\s+/g, ' ').trim();
    return cleaned.length > 2000 ? `${cleaned.slice(0, 1997)}...` : cleaned;
  }

  async function flushPendingKeywordBlocks() {
    if (flushingKeywordBlocks || !pendingKeywordBlocks.size) return;
    flushingKeywordBlocks = true;
    try {
      while (pendingKeywordBlocks.size) {
        const batch = Array.from(pendingKeywordBlocks.values());
        pendingKeywordBlocks.clear();
        const names = batch.map((entry) => entry.username);
        const newlyBlocked = new Set(names.filter((name) => !blocked.has(name)));
        const changed = await blockUsersBulk(
          batch.map((entry) => ({
            username: entry.username,
            meta: buildBlockMeta({ reasonType: 'keyword', keyword: entry.keyword, source: entry.source })
          }))
        );
        if (newlyBlocked.size) {
          await appendLogEntries(
            batch
              .filter((entry) => newlyBlocked.has(entry.username))
              .map((entry) => ({
                timestamp: new Date().toISOString(),
                type: 'auto_block_keyword',
                user: entry.username,
                keyword: formatKeywordForLog(entry.keyword),
                regex: Boolean(entry.keyword && entry.keyword.regex),
                source: entry.source || 'unknown',
                url: entry.url || location.href,
                content: entry.content || ''
              }))
          );
        }
        if (changed) refreshAll();
      }
    } finally {
      flushingKeywordBlocks = false;
    }
  }

  async function recordSuspiciousEntries(entries) {
    const incoming = Array.isArray(entries) ? entries : [];
    if (!incoming.length) return;
    const blockEntries = [];
    const suspiciousLogEntries = [];
    let suspiciousChanged = false;

    for (const entry of incoming) {
      const username = normalize(entry && entry.username ? entry.username : entry);
      if (!username || blocked.has(username)) continue;

      const current = suspiciousUsers[username] || {
        count: 0,
        keywordHits: 0,
        subredditHits: 0,
        subreddits: {},
        lastReasonType: '',
        lastKeyword: '',
        lastSubreddit: '',
        lastSeen: 0,
        lastContent: '',
        lastHitKey: ''
      };

      const content = normalizeLoggedContent(entry && entry.content ? entry.content : '');
      const hitKey = String((entry && entry.hitKey) || '').trim();
      const sameHit = Boolean(
        (hitKey && current.lastHitKey && current.lastHitKey === hitKey) ||
          (!hitKey && content && current.lastContent && current.lastContent === content)
      );
      if (sameHit) continue;
      const isNewSuspicious = current.count === 0;

      current.count += 1;
      current.lastSeen = Date.now();
      current.lastReasonType = entry && entry.reasonType ? entry.reasonType : 'unknown';
      current.lastContent = content;
      current.lastHitKey = hitKey;

      if (entry && entry.reasonType === 'keyword') {
        current.keywordHits += 1;
        current.lastKeyword = formatKeywordForLog(entry.keyword);
      }
      if (entry && entry.reasonType === 'subreddit') {
        const sub = normalizeSub(entry.subreddit);
        current.subredditHits += 1;
        current.lastSubreddit = sub;
        current.subreddits[sub] = clampNumber(current.subreddits[sub], 0, 1000000, 0) + 1;
      }

      suspiciousUsers[username] = current;
      suspiciousChanged = true;

      if (isNewSuspicious) {
        suspiciousLogEntries.push({
          timestamp: new Date().toISOString(),
          type: 'added_to_suspicious_list',
          user: username,
          keyword: formatKeywordForLog(entry && entry.keyword ? entry.keyword : null),
          regex: Boolean(entry && entry.keyword && entry.keyword.regex),
          source: entry && entry.source ? entry.source : 'unknown',
          subreddit: entry && entry.subreddit ? normalizeSub(entry.subreddit) : '',
          url: entry && entry.url ? entry.url : location.href,
          content
        });
      }

      const subredditThresholdHit =
        current.lastSubreddit && clampNumber(current.subreddits[current.lastSubreddit], 0, 1000000, 0) >= suspiciousThreshold;
      if (current.count >= suspiciousThreshold || subredditThresholdHit) {
        const reasonLabel =
          entry && entry.reasonType === 'subreddit' && current.lastSubreddit
            ? `Reached suspicious threshold after repeated activity in blocked subreddit r/${current.lastSubreddit}`
            : `Reached suspicious threshold after keyword/filter activity${current.lastKeyword ? ` (${current.lastKeyword})` : ''}`;
        blockEntries.push({
          username,
          meta: buildBlockMeta({
            reasonType: 'suspicious',
            keyword: entry && entry.keyword ? entry.keyword : null,
            subreddit: current.lastSubreddit,
            source: entry && entry.source ? entry.source : '',
            reasonLabel
          })
        });
      }
    }

    if (suspiciousChanged) {
      await saveSuspiciousUsers();
    }
    if (suspiciousLogEntries.length) {
      await appendLogEntries(suspiciousLogEntries);
    }

    if (blockEntries.length) {
      const changed = await blockUsersBulk(blockEntries);
      if (changed) refreshAll();
    }
  }

  function queueKeywordBlocks(entries) {
    if (suspiciousModeEnabled) {
      void recordSuspiciousEntries(
        (Array.isArray(entries) ? entries : []).map((entry) => ({
          username: entry && entry.username ? entry.username : entry,
          keyword: entry && entry.keyword ? { value: entry.keyword.value, regex: Boolean(entry.keyword.regex) } : null,
          source: entry && entry.source ? entry.source : 'unknown',
          subreddit: getCurrentSubreddit(),
          reasonType: 'keyword',
          content: normalizeLoggedContent(entry && entry.content ? entry.content : ''),
          hitKey: entry && entry.hitKey ? entry.hitKey : '',
          url: entry && entry.url ? entry.url : location.href
        }))
      );
      return;
    }
    let queued = false;
    for (const entry of entries) {
      const norm = normalize(entry && entry.username ? entry.username : entry);
      if (!norm || blocked.has(norm)) continue;
      pendingKeywordBlocks.set(norm, {
        username: norm,
        keyword: entry && entry.keyword ? { value: entry.keyword.value, regex: Boolean(entry.keyword.regex) } : null,
        source: entry && entry.source ? entry.source : 'unknown',
        url: entry && entry.url ? entry.url : location.href,
        content: normalizeLoggedContent(entry && entry.content ? entry.content : '')
      });
      queued = true;
    }
    if (queued) {
      void flushPendingKeywordBlocks();
    }
  }

  function isInBody(link) {
    return BODY_SELECTORS.some((sel) => link.closest(sel));
  }

  function findAuthorLink(root) {
    if (!root || !root.querySelector) return null;
    for (const sel of AUTHOR_SELECTORS) {
      const link = root.querySelector(sel);
      if (link) return link;
    }

    const fallbackLinks = root.querySelectorAll(
      'a[href^="/user/"], a[href^="https://www.reddit.com/user/"], a[href^="https://old.reddit.com/user/"]'
    );
    let first = null;
    for (const link of fallbackLinks) {
      if (!first) first = link;
      if (!isInBody(link)) return link;
    }
    return first;
  }

  function findAuthorLinkDeep(root, depth = 0) {
    if (!root) return null;
    const direct = findAuthorLink(root);
    if (direct) return direct;

    if (root.shadowRoot) {
      const inShadow = findAuthorLinkDeep(root.shadowRoot, depth + 1);
      if (inShadow) return inShadow;
    }

    if (depth > 2 || !root.querySelectorAll) return null;

    const all = root.querySelectorAll('*');
    for (const el of all) {
      if (el.shadowRoot) {
        const found = findAuthorLinkDeep(el.shadowRoot, depth + 1);
        if (found) return found;
      }
    }
    return null;
  }

  function getAuthorLink(container) {
    const lightDom = findAuthorLinkDeep(container);
    if (lightDom) return { link: lightDom, root: container };
    return null;
  }

  function getAuthorFromAttributes(container) {
    if (!container || !container.getAttribute) return null;
    const candidates = [
      container.getAttribute('author'),
      container.getAttribute('data-author'),
      container.getAttribute('data-author-name'),
      container.getAttribute('data-user'),
      container.getAttribute('data-username')
    ];
    for (const candidate of candidates) {
      const cleaned = cleanUsername(candidate);
      if (cleaned) return cleaned;
    }
    return null;
  }

  function getAuthorFromChildren(container) {
    if (!container || !container.querySelectorAll) return null;
    const nodes = container.querySelectorAll('[author],[data-author],[data-author-name],[data-user],[data-username]');
    for (const node of nodes) {
      const cleaned = cleanUsername(
        node.getAttribute('author') ||
          node.getAttribute('data-author') ||
          node.getAttribute('data-author-name') ||
          node.getAttribute('data-user') ||
          node.getAttribute('data-username')
      );
      if (cleaned) return cleaned;
    }
    return null;
  }

  function applyToContainer(container) {
    if (!container || !container.querySelector) return;
    if (isPostContainer(container)) return;
    const commentTarget = (container.closest && container.closest('div.thing.comment')) || container;

    const found = getAuthorLink(container);
    const link = found ? found.link : null;
    const hrefUser = link ? extractUsernameFromHref(link.getAttribute('href')) : null;
    const textUser = link ? cleanUsername(link.textContent) : null;
    const attrUser = getAuthorFromAttributes(container);
    const childAttrUser = getAuthorFromChildren(container);
    const username = cleanUsername(hrefUser || textUser || attrUser || childAttrUser);
    if (!username) return;

    const subreddit = getSubredditFromContainer(container);
    if (isWhitelistedSub(subreddit)) {
      setCommentVisibility(commentTarget, false, '');
      container.classList.remove(HIDDEN_CLASS);
      const visibleThing = container.closest && container.closest('div.thing.comment');
      if (visibleThing) visibleThing.classList.remove(HIDDEN_CLASS);
      return;
    }

    const norm = normalize(username);
    const containerText = getPostText(container);
    const matches = getKeywordMatches(containerText);
    const autoBlockKeyword = isCommentContainer(container) ? matches.autoBlockKeyword : null;
    if (autoBlockKeyword) {
      queueKeywordBlocks([
        {
          username: norm,
          keyword: autoBlockKeyword,
          source: 'comment',
          url: location.href,
          content: containerText,
          hitKey: getContainerHitKey(commentTarget)
        }
      ]);
    }
    container.dataset.rbuAuthor = norm;
    const blockedByUser = blocked.has(norm);
    let reason = '';
    if (blockedByUser) {
      reason = `u/${username} is blocked. ${formatBlockReason(username)}`;
    } else if (autoBlockKeyword) {
      reason = suspiciousModeEnabled
        ? `Matched aggressive keyword ${formatKeywordForLog(autoBlockKeyword)} and added the author to the suspicious list.`
        : `Matched aggressive keyword ${formatKeywordForLog(autoBlockKeyword)} and auto-blocked the author.`;
    }

    const shouldHide = blockedByUser || Boolean(autoBlockKeyword);
    setCommentVisibility(commentTarget, shouldHide, reason);

    if (shouldHide) {
      if (container !== commentTarget) {
        container.classList.add(HIDDEN_CLASS);
      }
      const oldThing = container.closest && container.closest('div.thing');
      if (oldThing && oldThing !== commentTarget) oldThing.classList.add(HIDDEN_CLASS);
    } else {
      container.classList.remove(HIDDEN_CLASS);
      const oldThing = container.closest && container.closest('div.thing');
      if (oldThing && oldThing !== commentTarget) oldThing.classList.remove(HIDDEN_CLASS);
    }
  }

  function getUsernameFromContainer(container) {
    if (!container || !container.querySelector) return null;
    const found = getAuthorLink(container);
    const link = found ? found.link : null;
    const hrefUser = link ? extractUsernameFromHref(link.getAttribute('href')) : null;
    const textUser = link ? cleanUsername(link.textContent) : null;
    const attrUser = getAuthorFromAttributes(container);
    const childAttrUser = getAuthorFromChildren(container);
    const username = cleanUsername(hrefUser || textUser || attrUser || childAttrUser);
    if (!username) return null;
    return normalize(username);
  }

  function getPostText(container) {
    if (!container) return '';
    return (container.innerText || container.textContent || '').replace(/\s+/g, ' ').trim();
  }

  function getContainerHitKey(container) {
    if (!container || container.nodeType !== 1) return '';
    const candidates = [
      container.id,
      container.getAttribute && container.getAttribute('data-fullname'),
      container.getAttribute && container.getAttribute('data-comment-id'),
      container.getAttribute && container.getAttribute('data-post-id'),
      container.getAttribute && container.getAttribute('thingid'),
      container.getAttribute && container.getAttribute('name'),
      container.getAttribute && container.getAttribute('comment-id'),
      container.getAttribute && container.getAttribute('post-id')
    ];
    for (const candidate of candidates) {
      if (candidate) return String(candidate);
    }
    const permalink = container.querySelector && container.querySelector('a[href*="/comments/"]');
    if (permalink) {
      const href = permalink.getAttribute('href') || permalink.href || '';
      if (href) return String(href);
    }
    return '';
  }

  function extractSubredditFromHref(href) {
    if (!href) return null;
    try {
      const url = new URL(href, location.origin);
      const match = url.pathname.match(/^\/r\/([^\/?#]+)/i);
      return match && match[1] ? normalizeSub(match[1]) : null;
    } catch (err) {
      return null;
    }
  }

  function getSubredditFromContainer(container) {
    if (!container || !container.querySelectorAll) return getCurrentSubreddit();
    const attrCandidates = [
      container.getAttribute && container.getAttribute('subreddit'),
      container.getAttribute && container.getAttribute('data-subreddit'),
      container.getAttribute && container.getAttribute('community')
    ];
    for (const candidate of attrCandidates) {
      const sub = normalizeSub(candidate);
      if (sub) return sub;
    }

    const links = container.querySelectorAll(
      'a[href^="/r/"], a[href^="https://www.reddit.com/r/"], a[href^="https://old.reddit.com/r/"]'
    );
    for (const link of links) {
      if (isInBody(link)) continue;
      const sub = extractSubredditFromHref(link.getAttribute('href'));
      if (sub) return sub;
    }

    return getCurrentSubreddit();
  }

  function isWhitelistedSub(subreddit) {
    const sub = normalizeSub(subreddit);
    return Boolean(sub && whitelistedSubs.has(sub));
  }

  function getMatchingKeyword(text, keywords) {
    if (!text || !keywords.length) return null;
    const normalizedText = normalizeDoubleQuotes(text);
    const textLower = normalizedText.toLowerCase();
    for (const keyword of keywords) {
      if (!keyword || !keyword.value) continue;
      if (keyword.regex) {
        try {
          if (new RegExp(keyword.value, 'i').test(normalizedText)) return keyword;
        } catch (err) {
          continue;
        }
      }
      if (textLower.includes(normalizeDoubleQuotes(keyword.value).toLowerCase())) return keyword;
    }
    return null;
  }

  function getKeywordMatches(text) {
    const safeKeyword = getMatchingKeyword(text, safeKeywords);
    if (safeKeyword) {
      return { safeKeyword, hideKeyword: null, autoBlockKeyword: null };
    }
    return {
      safeKeyword: null,
      hideKeyword: getMatchingKeyword(text, hideKeywords),
      autoBlockKeyword: getMatchingKeyword(text, aggressiveKeywords)
    };
  }

  function isCommentContainer(container) {
    if (!container || !container.matches) return false;
    return container.matches('shreddit-comment,[data-test-id="comment"],div.comment,div.thing.comment');
  }

  function getPlaceholderId(target) {
    if (!target.dataset.rbuPlaceholderId) {
      target.dataset.rbuPlaceholderId = `rbu-placeholder-${Math.random().toString(36).slice(2)}`;
    }
    return target.dataset.rbuPlaceholderId;
  }

  function removePlaceholder(target) {
    if (!target || !target.dataset) return;
    const id = target.dataset.rbuPlaceholderId;
    if (id) {
      const existing = document.querySelector(`[data-rbu-placeholder-for="${id}"]`);
      if (existing) existing.remove();
    }
    target.classList.remove(HIDDEN_CLASS);
  }

  function ensurePlaceholder(target, reason, label) {
    if (!target || !target.parentNode) return;
    if (hideBlockedPostsCompletely) {
      removePlaceholder(target);
      target.classList.add(HIDDEN_CLASS);
      return;
    }
    if (target.dataset.rbuShowAnyway === '1') {
      removePlaceholder(target);
      return;
    }

    const id = getPlaceholderId(target);
    let placeholder = document.querySelector(`[data-rbu-placeholder-for="${id}"]`);
    if (!placeholder) {
      placeholder = document.createElement('div');
      placeholder.className = 'rbu-post-placeholder';
      placeholder.dataset.rbuPlaceholderFor = id;

      const text = document.createElement('div');
      text.className = 'rbu-post-placeholder-text';
      placeholder.appendChild(text);

      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'rbu-post-placeholder-button';
      button.textContent = 'Show anyway';
      button.addEventListener('click', () => {
        target.dataset.rbuShowAnyway = '1';
        removePlaceholder(target);
      });
      placeholder.appendChild(button);
    }

    const text = placeholder.querySelector('.rbu-post-placeholder-text');
    if (text) {
      text.textContent = `${label} hidden. ${reason}`;
    }

    if (target.previousSibling !== placeholder) {
      target.parentNode.insertBefore(placeholder, target);
    }
    target.classList.add(HIDDEN_CLASS);
  }

  function setPostVisibility(target, shouldHide, reason) {
    if (!target) return;
    if (!shouldHide) {
      removePlaceholder(target);
      return;
    }
    ensurePlaceholder(target, reason, 'Post');
  }

  function setCommentVisibility(target, shouldHide, reason) {
    if (!target) return;
    if (!shouldHide) {
      removePlaceholder(target);
      return;
    }
    ensurePlaceholder(target, reason, 'Comment');
  }

  function applyRedditPosts(root = document) {
    if (isOldRedditHost()) return;
    const base = root && root.querySelectorAll ? root : document;
    const posts = [];

    if (base.nodeType === 1 && base.matches && base.matches(REDDIT_POST_SELECTOR)) {
      posts.push(base);
    }
    base.querySelectorAll(REDDIT_POST_SELECTOR).forEach((el) => posts.push(el));

    const seen = new Set();
    for (const post of posts) {
      if (!post || seen.has(post)) continue;
      seen.add(post);
      if (isCommentContainer(post)) continue;

      const username = getUsernameFromContainer(post);
      const subreddit = getSubredditFromContainer(post);
      if (isWhitelistedSub(subreddit)) {
        setPostVisibility(post, false);
        continue;
      }
      const postText = getPostText(post);
      const matches = getKeywordMatches(postText);
      const hideByKeyword = matches.hideKeyword;
      const autoBlockKeyword = matches.autoBlockKeyword;
      if (autoBlockKeyword && username) {
        queueKeywordBlocks([
          {
            username,
            keyword: autoBlockKeyword,
            source: 'post',
            url: location.href,
            content: postText,
            hitKey: getContainerHitKey(post)
          }
        ]);
      }

      const blockedByUser = Boolean(username && blocked.has(username));
      let reason = '';
      if (blockedByUser && username) {
        reason = `u/${username} is blocked. ${formatBlockReason(username)}`;
      } else if (hideByKeyword) {
        reason = `Matched hide-only keyword ${formatKeywordForLog(hideByKeyword)}.`;
      } else if (autoBlockKeyword) {
        reason = suspiciousModeEnabled
          ? `Matched aggressive keyword ${formatKeywordForLog(autoBlockKeyword)} and added the author to the suspicious list.`
          : `Matched aggressive keyword ${formatKeywordForLog(autoBlockKeyword)} and auto-blocked the author.`;
      }

      setPostVisibility(post, blockedByUser || Boolean(hideByKeyword) || Boolean(autoBlockKeyword), reason);
    }
  }

  function getCurrentSubreddit() {
    const match = location.pathname.match(/\/r\/([^\/?#]+)/i);
    if (match && match[1]) return normalizeSub(match[1]);
    return null;
  }

  function isPostPage() {
    return /\/comments\//i.test(location.pathname);
  }

  function isListingPage() {
    if (!/\/r\//i.test(location.pathname)) return false;
    if (isPostPage()) return false;
    return true;
  }

  function shouldAutoBlock() {
    const sub = getCurrentSubreddit();
    if (!sub) return false;
    if (!blockedSubs.has(sub)) return false;
    if (whitelistedSubs.has(sub)) return false;
    return isPostPage();
  }

  function shouldSweepListing() {
    if (!autoSweepEnabled) return false;
    const sub = getCurrentSubreddit();
    if (!sub) return false;
    if (!blockedSubs.has(sub)) return false;
    if (whitelistedSubs.has(sub)) return false;
    if (!isListingPage()) return false;
    return true;
  }

  function isSweepTab() {
    try {
      const url = new URL(location.href);
      return url.searchParams.has(SWEEP_QUERY_KEY);
    } catch (err) {
      return false;
    }
  }

  function hideSweepMediaElement(element) {
    if (!element || element.nodeType !== 1) return;
    element.classList.add(HIDDEN_CLASS);
    element.style.setProperty('display', 'none', 'important');
    element.style.setProperty('visibility', 'hidden', 'important');
    element.style.setProperty('opacity', '0', 'important');
    element.style.setProperty('max-height', '0', 'important');
    element.style.setProperty('max-width', '0', 'important');
    element.style.setProperty('pointer-events', 'none', 'important');
  }

  function disableSweepMediaElement(element) {
    if (!element || element.nodeType !== 1) return;
    if (element.dataset.rbuSweepMediaDisabled === '1') {
      hideSweepMediaElement(element);
      return;
    }
    element.dataset.rbuSweepMediaDisabled = '1';

    const tag = element.tagName.toLowerCase();
    if (tag === 'video' || tag === 'audio') {
      try {
        element.pause();
      } catch (err) {
        // ignore
      }
      element.removeAttribute('src');
      element.removeAttribute('poster');
      element.removeAttribute('autoplay');
      element.removeAttribute('controls');
      element.preload = 'none';
      element.querySelectorAll('source').forEach((source) => {
        source.removeAttribute('src');
        source.removeAttribute('srcset');
        hideSweepMediaElement(source);
        source.remove();
      });
      try {
        element.load();
      } catch (err) {
        // ignore
      }
    } else if (tag === 'img' || tag === 'source') {
      element.removeAttribute('src');
      element.removeAttribute('srcset');
      element.removeAttribute('sizes');
      if ('src' in element) element.src = '';
      if ('srcset' in element) element.srcset = '';
    } else if (tag === 'iframe' || tag === 'embed' || tag === 'object') {
      element.removeAttribute('src');
      element.removeAttribute('data');
      if (tag === 'iframe') {
        try {
          element.src = 'about:blank';
        } catch (err) {
          // ignore
        }
      }
    } else if (tag === 'picture') {
      element.querySelectorAll('img,source').forEach(disableSweepMediaElement);
    }

    if (element.style && /background-image/i.test(element.getAttribute('style') || '')) {
      element.style.setProperty('background-image', 'none', 'important');
      element.style.setProperty('background', 'none', 'important');
    }

    hideSweepMediaElement(element);
    if (tag !== 'picture') {
      element.remove();
      if (element.isConnected) {
        hideSweepMediaElement(element);
      }
    }
  }

  function stripSweepMedia(root = document) {
    if (!isSweepTab()) return;
    const base = root === document ? document : root && root.querySelectorAll ? root : null;
    if (!base) return;

    if (base.nodeType === 1 && base.matches && base.matches(SWEEP_MEDIA_SELECTOR)) {
      disableSweepMediaElement(base);
    }
    base.querySelectorAll(SWEEP_MEDIA_SELECTOR).forEach(disableSweepMediaElement);
    base.querySelectorAll('[style*="background-image"],[poster]').forEach((element) => {
      if (element.hasAttribute('poster')) {
        element.removeAttribute('poster');
      }
      if (element.style) {
        element.style.setProperty('background-image', 'none', 'important');
        element.style.setProperty('background', 'none', 'important');
      }
      hideSweepMediaElement(element);
    });
  }

  function startSweepMediaBlocker() {
    if (!isSweepTab()) return;

    document.addEventListener(
      'play',
      (event) => {
        if (event.target && typeof event.target.pause === 'function') {
          try {
            event.target.pause();
          } catch (err) {
            // ignore
          }
        }
      },
      true
    );

    const observeTarget = document.documentElement;
    if (!observeTarget) return;

    const observer = new MutationObserver((mutations) => {
      for (const mutation of mutations) {
        if (mutation.type === 'attributes') {
          if (
            mutation.target &&
            mutation.target.matches &&
            (mutation.target.matches(SWEEP_MEDIA_SELECTOR) ||
              mutation.target.hasAttribute('poster') ||
              /background-image/i.test(mutation.target.getAttribute('style') || ''))
          ) {
            disableSweepMediaElement(mutation.target);
          }
          continue;
        }
        for (const node of mutation.addedNodes) {
          stripSweepMedia(node);
        }
      }
    });

    observer.observe(observeTarget, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ['src', 'srcset', 'poster', 'style']
    });

    stripSweepMedia(observeTarget);
  }

  function addSweepMarker(urlString) {
    try {
      const url = new URL(urlString, location.origin);
      if (!url.searchParams.has(SWEEP_QUERY_KEY)) {
        url.searchParams.set(SWEEP_QUERY_KEY, '1');
      }
      return url.toString();
    } catch (err) {
      return urlString;
    }
  }

  function getPostIdFromUrl(urlString) {
    if (!urlString) return null;
    try {
      const url = new URL(urlString, location.origin);
      const match = url.pathname.match(/\/comments\/([^\/?#]+)/i);
      if (match) return match[1];
    } catch (err) {
      return null;
    }
    return null;
  }

  function getSweepSeen() {
    try {
      const raw = sessionStorage.getItem('rbuSweepSeen');
      if (!raw) return new Set();
      const arr = JSON.parse(raw);
      if (!Array.isArray(arr)) return new Set();
      return new Set(arr);
    } catch (err) {
      return new Set();
    }
  }

  function saveSweepSeen(seen) {
    try {
      sessionStorage.setItem('rbuSweepSeen', JSON.stringify(Array.from(seen)));
    } catch (err) {
      // ignore
    }
  }

  function getPostLink(container) {
    if (!container || !container.querySelector) return null;
    const link = container.querySelector('a[href*="/comments/"]');
    return link || null;
  }

  function isPostContainer(container) {
    if (!container || container.nodeType !== 1) return false;
    if (
      container.matches &&
      container.matches('shreddit-post,[data-testid="post-container"],div.Post,div.thing.link')
    )
      return true;
    return false;
  }

  function parseCompactNumber(raw) {
    if (raw === null || raw === undefined) return null;
    const cleaned = String(raw).trim().toLowerCase().replace(/,/g, '');
    if (!cleaned || cleaned.includes('vote') || cleaned.includes('hidden')) return null;
    const match = cleaned.match(/(-?\d+(?:\.\d+)?)\s*([km]?)/i);
    if (!match) return null;
    const value = Number(match[1]);
    if (!Number.isFinite(value)) return null;
    const suffix = (match[2] || '').toLowerCase();
    const multiplier = suffix === 'k' ? 1000 : suffix === 'm' ? 1000000 : 1;
    return Math.round(value * multiplier);
  }

  function getScoreFromContainer(container) {
    if (!container || !container.querySelectorAll) return null;
    const directScore = parseCompactNumber(
      (container.getAttribute && (container.getAttribute('data-score') || container.getAttribute('score'))) || ''
    );
    if (directScore !== null) return directScore;

    const selectors = [
      '[data-score]',
      '[score]',
      '.score.unvoted',
      '.score',
      'faceplate-number',
      'shreddit-score',
      '[slot="score"]',
      '[data-testid="vote-score"]'
    ];

    for (const selector of selectors) {
      const nodes = container.querySelectorAll(selector);
      for (const node of nodes) {
        const score =
          parseCompactNumber(node.getAttribute && node.getAttribute('data-score')) ??
          parseCompactNumber(node.getAttribute && node.getAttribute('score')) ??
          parseCompactNumber(node.getAttribute && node.getAttribute('number')) ??
          parseCompactNumber(node.getAttribute && node.getAttribute('aria-label')) ??
          parseCompactNumber(node.textContent);
        if (score !== null) return score;
      }
    }

    return null;
  }

  function getTimestampFromContainer(container) {
    if (!container || !container.querySelectorAll) return null;
    const selectors = ['time[datetime]', 'faceplate-timeago[ts]', 'faceplate-timeago[datetime]', '[data-timestamp]'];
    for (const selector of selectors) {
      const node = container.matches && container.matches(selector) ? container : container.querySelector(selector);
      if (!node) continue;
      const tsAttr =
        (node.getAttribute && (node.getAttribute('datetime') || node.getAttribute('ts') || node.getAttribute('data-timestamp'))) ||
        '';
      if (!tsAttr) continue;
      if (/^\d+$/.test(tsAttr)) {
        const numeric = Number(tsAttr);
        if (Number.isFinite(numeric)) {
          return numeric < 1000000000000 ? numeric * 1000 : numeric;
        }
      }
      const parsed = Date.parse(tsAttr);
      if (!Number.isNaN(parsed)) return parsed;
    }
    return null;
  }

  function isPostOlderThanSweepLimit(container) {
    if (!sweepMaxPostAgeHours) return false;
    const timestamp = getTimestampFromContainer(container);
    if (!timestamp) return false;
    return Date.now() - timestamp > sweepMaxPostAgeHours * 60 * 60 * 1000;
  }

  function shouldSkipSweepEntryByScore(container) {
    if (!sweepScoreExceptionEnabled) return false;
    const score = getScoreFromContainer(container);
    if (score === null) return false;
    const min = Math.min(sweepScoreMin, sweepScoreMax);
    const max = Math.max(sweepScoreMin, sweepScoreMax);
    return score >= min && score <= max;
  }

  function pickNextPostLink() {
    const containers = [];
    collectContainers(document.body, containers);
    if (!containers.length) return null;

    const seen = getSweepSeen();
    for (const container of containers) {
      if (!isPostContainer(container)) continue;
      const link = getPostLink(container);
      if (!link) continue;
      const postId = getPostIdFromUrl(link.getAttribute('href') || '');
      if (!postId || seen.has(postId)) continue;

      const username = getUsernameFromContainer(container);
      if (!username) continue;
      if (blocked.has(username)) continue;
      if (isPostOlderThanSweepLimit(container)) {
        sweepAgeStopActive = true;
        return { stop: true };
      }

      seen.add(postId);
      saveSweepSeen(seen);
      return { link };
    }

    return null;
  }

  function scheduleSweepRetry() {
    if (sweepRetryTimer) return;
    sweepRetryTimer = setTimeout(() => {
      sweepRetryTimer = null;
      scheduleSweep();
    }, 1500);
  }

  function scheduleSweepCooldown() {
    if (sweepCooldownTimer) return;
    sweepCooldownTimer = setTimeout(() => {
      sweepCooldownTimer = null;
      sweepInProgress = false;
      scheduleSweep();
    }, autoSweepDelayMs);
  }

  function scheduleSweep() {
    if (!shouldSweepListing()) return;
    if (sweepInProgress) return;
    if (sweepAgeStopActive) return;
    const nextPost = pickNextPostLink();
    if (!nextPost) {
      scheduleSweepRetry();
      return;
    }
    if (nextPost.stop) return;

    sweepInProgress = true;
    const sweepUrl = addSweepMarker(nextPost.link.href);
    api.runtime.sendMessage({ type: 'rbu-open-sweep-tab', url: sweepUrl }, () => {
      if (api.runtime.lastError) {
        sweepInProgress = false;
        scheduleSweepRetry();
        return;
      }
      scheduleSweepCooldown();
    });
  }

  function scheduleSweepTabClose() {
    if (!autoSweepEnabled) return;
    if (!shouldAutoBlock()) return;
    if (!isSweepTab()) return;
    if (sweepReturnTimer) return;

    sweepReturnTimer = setTimeout(() => {
      sweepReturnTimer = null;
      api.runtime.sendMessage({ type: 'rbu-close-sweep-tab' });
    }, autoSweepDelayMs);
  }

  function collectContainers(root, output) {
    if (!root || !root.querySelectorAll) return;
    if (root.nodeType === 1 && root.matches && root.matches(CONTAINER_SELECTOR)) {
      output.push(root);
    }
    root.querySelectorAll(CONTAINER_SELECTOR).forEach((el) => output.push(el));
    if (root.shadowRoot) {
      collectContainers(root.shadowRoot, output);
    }
    root.querySelectorAll('*').forEach((el) => {
      if (el.shadowRoot) collectContainers(el.shadowRoot, output);
    });
  }

  async function autoBlockFromRoot(root) {
    if (!shouldAutoBlock()) return;
    const containers = [];
    collectContainers(root, containers);
    if (!containers.length) return;

    const subreddit = getCurrentSubreddit();
    const entries = [];
    for (const container of containers) {
      if (shouldSkipSweepEntryByScore(container)) continue;
      const username = getUsernameFromContainer(container);
      if (username) {
        entries.push({
          username,
          subreddit,
          reasonType: 'subreddit',
          source: 'auto_sweep',
          content: getPostText(container),
          hitKey: getContainerHitKey(container),
          url: location.href
        });
      }
    }

    if (!entries.length) return;
    if (suspiciousModeEnabled) {
      await recordSuspiciousEntries(entries);
      return;
    }
    const changed = await blockUsersBulk(
      entries.map((entry) => ({
        username: entry.username,
        meta: buildBlockMeta({
          reasonType: 'subreddit',
          subreddit: entry.subreddit,
          source: entry.source
        })
      }))
    );
    if (changed) refreshAll();
  }

  function processTree(root) {
    if (!root || !root.querySelectorAll) return;

    if (root.nodeType === 1 && root.matches && root.matches(CONTAINER_SELECTOR)) {
      applyToContainer(root);
    }

    root.querySelectorAll(CONTAINER_SELECTOR).forEach(applyToContainer);

    if (root.shadowRoot) {
      processTree(root.shadowRoot);
    }

    root.querySelectorAll('*').forEach((el) => {
      if (el.shadowRoot) processTree(el.shadowRoot);
    });

    autoBlockFromRoot(root);
    if (shouldSweepListing()) {
      scheduleSweep();
    } else if (shouldAutoBlock()) {
      scheduleSweepTabClose();
    }
  }

  function getOldRedditAuthor(thing) {
    if (!thing) return null;
    const attr = cleanUsername(thing.getAttribute('data-author') || '');
    if (attr) return attr;
    const link = thing.querySelector('p.tagline a.author, a.author');
    return link ? cleanUsername(link.textContent || '') : null;
  }

  function isOldRedditHost() {
    return /^old\.reddit\.com$/i.test(location.hostname);
  }

  function applyOldReddit(root = document) {
    if (!isOldRedditHost()) return;
    const base = root && root.querySelectorAll ? root : document;
    const authorLinks = [];
    if (base.nodeType === 1 && base.matches && base.matches('a.author')) {
      authorLinks.push(base);
    }
    base.querySelectorAll('a.author').forEach((el) => authorLinks.push(el));

    for (const link of authorLinks) {
      const author = cleanUsername(link.textContent || '') || extractUsernameFromHref(link.getAttribute('href') || '');
      const norm = author ? normalize(author) : '';

      // For old.reddit posts, remove the nearest "entry unvoted" node from local DOM.
      const entry = link.closest('.entry.unvoted') || link.closest('.entry');
      if (!entry) continue;
      const thing = entry.closest('div.thing');
      if (thing && thing.classList.contains('comment')) continue;
      const target = thing || entry;
      const subreddit = getSubredditFromContainer(thing || entry);
      if (isWhitelistedSub(subreddit)) {
        setPostVisibility(target, false);
        continue;
      }
      const postText = getPostText(thing || entry);
      const matches = getKeywordMatches(postText);
      const hideByKeyword = matches.hideKeyword;
      const autoBlockKeyword = matches.autoBlockKeyword;
      if (autoBlockKeyword && author) {
        queueKeywordBlocks([
          {
            username: author,
            keyword: autoBlockKeyword,
            source: 'post',
            url: location.href,
            content: postText,
            hitKey: getContainerHitKey(target)
          }
        ]);
      }
      const blockedByUser = Boolean(blocked.has(norm));
      let reason = '';
      if (blockedByUser && author) {
        reason = `u/${author} is blocked. ${formatBlockReason(author)}`;
      } else if (hideByKeyword) {
        reason = `Matched hide-only keyword ${formatKeywordForLog(hideByKeyword)}.`;
      } else if (autoBlockKeyword) {
        reason = suspiciousModeEnabled
          ? `Matched aggressive keyword ${formatKeywordForLog(autoBlockKeyword)} and added the author to the suspicious list.`
          : `Matched aggressive keyword ${formatKeywordForLog(autoBlockKeyword)} and auto-blocked the author.`;
      }

      setPostVisibility(target, blockedByUser || Boolean(hideByKeyword) || Boolean(autoBlockKeyword), reason);
    }
  }

  function refreshAll() {
    processTree(document.body);
    applyRedditPosts(document.body);
    applyOldReddit(document.body);
    document.querySelectorAll('button.rbu-block-btn').forEach((btn) => btn.remove());
  }

  function startObserver() {
    const observer = new MutationObserver((mutations) => {
      for (const mutation of mutations) {
        for (const node of mutation.addedNodes) {
          processTree(node);
        }
      }
    });

    observer.observe(document.body, { childList: true, subtree: true });
  }

  async function init() {
    await loadBlocked();
    refreshAll();
    startObserver();
  }

  api.storage.onChanged.addListener(async (changes) => {
    let changed = false;
    if (changes[STORAGE_KEY]) {
      const next = changes[STORAGE_KEY].newValue || [];
      blocked = new Set(next.map(normalize).filter(Boolean));
      changed = true;
    }
    if (changes[SUB_STORAGE_KEY]) {
      const nextSubs = changes[SUB_STORAGE_KEY].newValue || [];
      blockedSubs = new Set(nextSubs.map(normalizeSub).filter(Boolean));
      changed = true;
    }
    if (changes[SUB_WHITELIST_KEY]) {
      const nextSubs = changes[SUB_WHITELIST_KEY].newValue || [];
      whitelistedSubs = new Set(nextSubs.map(normalizeSub).filter(Boolean));
      changed = true;
    }
    if (changes[SAFE_KEYWORDS_KEY]) {
      safeKeywords = normalizeKeywordList(changes[SAFE_KEYWORDS_KEY].newValue);
      changed = true;
    }
    if (changes[HIDE_KEYWORDS_KEY]) {
      hideKeywords = normalizeKeywordList(changes[HIDE_KEYWORDS_KEY].newValue);
      changed = true;
    }
    if (changes[AGGRESSIVE_KEYWORDS_KEY]) {
      aggressiveKeywords = normalizeKeywordList(changes[AGGRESSIVE_KEYWORDS_KEY].newValue);
      changed = true;
    }
    if (changes[SUSPICIOUS_MODE_KEY]) {
      suspiciousModeEnabled = Boolean(changes[SUSPICIOUS_MODE_KEY].newValue);
      changed = true;
    }
    if (changes[SUSPICIOUS_THRESHOLD_KEY]) {
      suspiciousThreshold = clampNumber(changes[SUSPICIOUS_THRESHOLD_KEY].newValue, 1, 100, 2);
      changed = true;
    }
    if (changes[SUSPICIOUS_USERS_KEY]) {
      suspiciousUsers = normalizeSuspiciousMap(changes[SUSPICIOUS_USERS_KEY].newValue);
      changed = true;
    }
    if (changes[USER_META_KEY]) {
      userMeta = normalizeUserMetaMap(changes[USER_META_KEY].newValue);
      changed = true;
    }
    if (changes[HIDE_BLOCKED_POSTS_COMPLETELY_KEY]) {
      hideBlockedPostsCompletely = Boolean(changes[HIDE_BLOCKED_POSTS_COMPLETELY_KEY].newValue);
      changed = true;
    }
    if (changes[BLOCK_DECAY_ENABLED_KEY]) {
      blockDecayEnabled = Boolean(changes[BLOCK_DECAY_ENABLED_KEY].newValue);
      changed = true;
    }
    if (changes[BLOCK_DECAY_DAYS_KEY]) {
      blockDecayDays = clampNumber(changes[BLOCK_DECAY_DAYS_KEY].newValue, 1, 3650, 30);
      changed = true;
    }
    if (changes[SWEEP_KEY]) {
      autoSweepEnabled = Boolean(changes[SWEEP_KEY].newValue);
      changed = true;
    }
    if (changes[SWEEP_DELAY_KEY]) {
      const delay = Number(changes[SWEEP_DELAY_KEY].newValue);
      if (Number.isFinite(delay) && delay >= 500 && delay <= 30000) {
        autoSweepDelayMs = delay;
      }
      changed = true;
    }
    if (changes[SWEEP_SCORE_EXCEPTION_ENABLED_KEY]) {
      sweepScoreExceptionEnabled = Boolean(changes[SWEEP_SCORE_EXCEPTION_ENABLED_KEY].newValue);
      changed = true;
    }
    if (changes[SWEEP_SCORE_MIN_KEY]) {
      sweepScoreMin = clampNumber(changes[SWEEP_SCORE_MIN_KEY].newValue, -1000000, 1000000, -1);
      changed = true;
    }
    if (changes[SWEEP_SCORE_MAX_KEY]) {
      sweepScoreMax = clampNumber(changes[SWEEP_SCORE_MAX_KEY].newValue, -1000000, 1000000, 1);
      changed = true;
    }
    if (changes[SWEEP_MAX_POST_AGE_HOURS_KEY]) {
      sweepMaxPostAgeHours = clampNumber(changes[SWEEP_MAX_POST_AGE_HOURS_KEY].newValue, 0, 87600, 0);
      sweepAgeStopActive = false;
      changed = true;
    }
    if (changes[BLOCK_DECAY_ENABLED_KEY] || changes[BLOCK_DECAY_DAYS_KEY]) {
      await pruneExpiredBlocks();
    }
    if (changed) refreshAll();
  });

  startSweepMediaBlocker();

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init, { once: true });
  } else {
    init();
  }
})();


